--
-- PostgreSQL database cluster dump
--

\restrict d3gGgoZy7aOFky8ISL12FYTzAVO9xhbAyNCRVnwwFsM2XJ7kM9BJbQF7rQhyJlX

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin;
ALTER ROLE admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:4l4wLN7Qq9kZuGRiGAWpIw==$jdR6B7fC42qGNZOQgp5Gxd7y26Asyr88p9eTAnSHpxo=:jPqlMrrj0/v/31Et+CMUg0/im2UwihD5J/n/TtDGMNo=';

--
-- User Configurations
--








\unrestrict d3gGgoZy7aOFky8ISL12FYTzAVO9xhbAyNCRVnwwFsM2XJ7kM9BJbQF7rQhyJlX

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict NYTe9dLATMB7kloQuGk8aDgmuqe1jWIYOETURhSFXD7XEBMLzOjzKPLAzroDLtH

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NYTe9dLATMB7kloQuGk8aDgmuqe1jWIYOETURhSFXD7XEBMLzOjzKPLAzroDLtH

--
-- Database "admin_db" dump
--

--
-- PostgreSQL database dump
--

\restrict AoRYRQh0JvVyjZNP5kh4eRi0bpGlOLxSKYaVIgahRwaiHdn53l40RRGfntRbTXm

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: admin_db; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE admin_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE admin_db OWNER TO admin;

\unrestrict AoRYRQh0JvVyjZNP5kh4eRi0bpGlOLxSKYaVIgahRwaiHdn53l40RRGfntRbTXm
\connect admin_db
\restrict AoRYRQh0JvVyjZNP5kh4eRi0bpGlOLxSKYaVIgahRwaiHdn53l40RRGfntRbTXm

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: saga_state_phase_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.saga_state_phase_enum AS ENUM (
    'FORWARD',
    'COMPENSATING',
    'DONE',
    'FAILED'
);


ALTER TYPE public.saga_state_phase_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_sell; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_sell (
    id integer NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    url character varying NOT NULL,
    description character varying NOT NULL,
    price integer NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    partner_id integer NOT NULL,
    buyer_id integer,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.accounts_sell OWNER TO admin;

--
-- Name: accounts_sell_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_sell_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_sell_id_seq OWNER TO admin;

--
-- Name: accounts_sell_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_sell_id_seq OWNED BY public.accounts_sell.id;


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.outbox_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "sagaType" character varying NOT NULL,
    payload jsonb NOT NULL,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "nextRetryAt" timestamp with time zone,
    "lastError" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.outbox_events OWNER TO admin;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    url_anh character varying NOT NULL,
    content text NOT NULL,
    editor_id integer NOT NULL,
    editor_realname character varying NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    create_at timestamp without time zone DEFAULT now() NOT NULL,
    update_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.posts OWNER TO admin;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO admin;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: saga_state; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.saga_state (
    saga_id uuid NOT NULL,
    phase public.saga_state_phase_enum DEFAULT 'FORWARD'::public.saga_state_phase_enum NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    completed_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    original_password text,
    original_email text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.saga_state OWNER TO admin;

--
-- Name: withdraw_money; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.withdraw_money (
    id integer NOT NULL,
    user_id integer NOT NULL,
    amount integer NOT NULL,
    bank_name character varying NOT NULL,
    bank_number character varying NOT NULL,
    bank_owner character varying NOT NULL,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    finance_id integer,
    request_at timestamp without time zone DEFAULT now() NOT NULL,
    success_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.withdraw_money OWNER TO admin;

--
-- Name: withdraw_money_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.withdraw_money_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.withdraw_money_id_seq OWNER TO admin;

--
-- Name: withdraw_money_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.withdraw_money_id_seq OWNED BY public.withdraw_money.id;


--
-- Name: accounts_sell id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_sell ALTER COLUMN id SET DEFAULT nextval('public.accounts_sell_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: withdraw_money id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.withdraw_money ALTER COLUMN id SET DEFAULT nextval('public.withdraw_money_id_seq'::regclass);


--
-- Data for Name: accounts_sell; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_sell (id, username, password, url, description, price, status, partner_id, buyer_id, "createdAt") FROM stdin;
1	thanhle	123456	https://cdn3.upanh.info/upload/server-sw3/images/Qu%E1%BB%91c%20t%E1%BA%BF%20ph%E1%BB%A5%20n%E1%BB%AF/Nick/Nick%20So%20Sinh%20Co%20D%E1%BB%87%20T%E1%BB%AD.jpg	Acc sơ sinh có đệ tử	20000	ACTIVE	1	\N	2026-04-05 17:42:26.682
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.outbox_events (id, "sagaType", payload, status, retries, "maxRetries", "nextRetryAt", "lastError", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.posts (id, title, url_anh, content, editor_id, editor_realname, status, create_at, update_at) FROM stdin;
1	Sự kiện Cá tháng 4 2026	https://betaforum.ngocrongonline.com/app/view/forum/03299fa84e.png	Chào các cư dân,\nBQT sẽ bảo trì cập nhật "Sự kiện Cá tháng 4 2026".\nThời gian diễn ra sự kiện: từ thời gian bảo trì xong - 20/04\n1. Sự kiện x3 TNSM, thẻ nạp\nThời gian diễn ra sự kiện:\n- x3 Thẻ nạp từ ngày 01/04 - 02/04\n- x3 TNSM từ ngày 01/04/ - 02/04\n2. Nhiệm vụ KOL\nCác cư dân tới đảo Kame gặp Quy Lão để xem thông tin và tiến độ nhiệm vụ đang thực hiện.\nPhần thưởng bao gồm:\n- Phần thưởng thường: Hoàn thành tất cả nhiệm vụ và nhận thưởng.\n- Phần thưởng VIP: Sau khi hoàn thành nhiệm vụ thường, cần "Vé nhiệm vụ tháng 4" (Nạp 70 ngọc xanh sẽ nhận được vật phẩm này) để nhận thưởng.\n3. Mở bán vật phẩm tại NPC Chi Chi\n- Trong thời gian sự kiện, cư dân có thể đến NPC Chi Chi tại đảo Kame để có thể mua một số vật phẩm mới.\n- Khi các cư dân mua vật phẩm "Hộp Cá Tháng Tư" sẽ được tính điểm vào sự kiện đua Top, 1 hộp = 1 điểm.\nPhần thưởng đua Top:\nTOP 1: Ra Đa Ngọc Rồng Vip 200, Rương Mảnh Thiên Sứ x999, Capsule 1 món kích hoạt x3, 2 Capsule vỡ, 1 Giáp Luyện Tập Cấp 5\nTOP 2: Ra Đa Ngọc Rồng Vip 100, Rương Mảnh Thiên Sứ x500, Capsule 1 món kích hoạt x2, 1 Capsule vỡ\nTOP 3: Ra Đa Ngọc Rồng Vip 60, Rương Mảnh Thiên Sứ x400, Capsule 1 món kích hoạt x1, 250 Mảnh Capsule vỡ\nTOP 4–10: Ra Đa Ngọc Rồng Vip 40, Rương Mảnh Thiên Sứ x300, Phiếu đổi capsule x50, 100 Mảnh Capsule vỡ\nTOP 11–50: Ra Đa Ngọc Rồng Vip 20, Rương Mảnh Thiên Sứ x100, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\nTOP 51–100: Ra Đa Ngọc Rồng Vip 10, Rương Mảnh Thiên Sứ x50, Phiếu đổi capsule x10\n4. Đổi điểm tại Quy Lão\n- Khi cư dân nạp ngọc xanh sẽ được tính điểm tại NPC Quy Lão (1 ngọc xanh = 1 điểm) để có thể đổi được một số vật phẩm, nếu may mắn sẽ nhận được vĩnh viễn.\n- Đặc biệt, khi đổi vật phẩm "Hộp Tháng Tư" sẽ được tính điểm đua Top, 1 hộp = 1 điểm.\nPhần thưởng đua Top:\nTOP 1: Capsule cải trang VIP x4, Sách Cũ x70, Capsule 1 món kích hoạt x3, 3 Capsule vỡ, 3 Con Dấu, 1 Giáp Luyện Tập Cấp 5\nTOP 2: Capsule cải trang VIP x3, Sách Cũ x60, Capsule 1 món kích hoạt x2, 2 Capsule vỡ, 2 Con Dấu, 1 Giáp Luyện Tập Cấp 5\nTOP 3: Capsule cải trang VIP x2, Sách Cũ x50, Capsule 1 món kích hoạt x1, 1 Capsule vỡ, 1 Con Dấu, 1 Giáp Luyện Tập Cấp 5\nTOP 4–10: Capsule cải trang VIP x1, Sách Cũ x20, Phiếu đổi capsule x50, 100 Mảnh Capsule vỡ\nTOP 11–50: Sách Cũ x10, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\nTOP 51–100: Sách Cũ x5, Phiếu đổi capsule x10\nChúc các Cư dân một ngày lễ vui vẻ, mạnh khỏe!!!	1	ADMIN HAI DANG	ACTIVE	2026-04-03 17:39:38.746	2026-04-03 17:39:38.746
2	ĐIỀU CHỈNH PHẦN THƯỞNG GIẢI SIÊU HẠNG	https://betaforum.ngocrongonline.com/app/view/forum/35b46c578c.jpg	Chào các Cư dân,\nBQT sẽ bảo trì cập nhật phần thưởng của Giải đấu Siêu hạng như sau:\nTOP 1: 200 Hồng Ngọc, 10 Rương Siêu Hạng, Danh hiệu cao thủ siêu hạng 3 ngày\nTOP 2: 100 Hồng Ngọc, 5 Rương Siêu Hạng\nTOP 3: 50 Hồng Ngọc, 2 Rương Siêu Hạng\nTOP 4–10: 20 Hồng Ngọc, 1 Rương Siêu Hạng\nTOP 11–20: 10 Hồng Ngọc\nTOP 21–100: 5 Hồng Ngọc\nTOP 101–1000: 2 Hồng Ngọc\n*Rương Siêu Hạng có thể mở ra các phần thưởng:\n- 50.000 vàng - 200.000 vàng\n- Mảnh bộ Sưu tập\n- Rương Sao Pha Lê Vip\n- Viên ngọc rồng 1 sao\n- Cải Trang Black Fide hạn sử dụng hoặc vĩnh viễn	1	ADMIN HAI DANG	ACTIVE	2026-04-03 17:40:38.542	2026-04-03 17:40:38.542
3	ĐÁNH RƠI SET KÍCH HOẠT - ĐUA TOP CĂNG THẲNG	https://forum.ngocrongonline.com/app/view/forum/1772763234733.png	Chào các Cư Dân,\nAdmin tổ chức Đua Top ĐÁNH RƠI SÉT KÍCH HOẠT với nội dung như sau:\n- Đánh rơi 1 món sét kích hoạt sẽ được 1 điểm ( tính cả đánh rơi set champa và gonhan)\n- Nếu bằng điểm người nhặt sau sẽ được xếp trên\n\nPhần Thưởng :\nTOP 1: 5 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi vĩnh viễn, 3 Capsule vỡ, Ra Đa Ngọc Rồng Vip 100\nTOP 2: 4 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi vĩnh viễn, 2 Capsule vỡ, Ra Đa Ngọc Rồng Vip 70\nTOP 3: 3 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi vĩnh viễn, 1 Capsule vỡ, Ra Đa Ngọc Rồng Vip 50\nTOP 4–10: 2 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi 180 ngày, 250 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 30\nTOP 11–50: Bóng Mờ Tuyết Rơi 90 ngày, 100 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 20\nTOP 51–100: Bóng Mờ Tuyết Rơi 60 ngày, 20 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 10\n\nChúc các Cư Dân Vui Vẻ !	1	ADMIN HAI DANG	ACTIVE	2026-04-03 17:41:25.103	2026-04-03 17:41:25.103
4	SỰ KIỆN PHÁI ĐẸP 08/03 - CỰC ĐẶC SẮC	https://forum.ngocrongonline.com/app/view/forum/90312478124.jpg	Chào các cư dân,\nMừng ngày Quốc tế Phụ nữ 8/3, BQT sẽ cập nhật chuỗi sự kiện đến các cư dân như sau:\nThời gian: từ 06/03/2026 hết 31/03/2026\n\n1. X3 TIỀM NĂNG SỨC MẠNH - KHUYẾN MÃI NẠP\n- Mở x3 TNSM và Khuyến mãi x3 nạp từ ngày 07/03/2026 đến hết ngày 08/03/2026.\n\n2. TẶNG QUÀ CHO NGƯỜI ĐẸP\n*Chú ý đặc biệt: Ấn sử dụng vật phẩm sự kiện để chế tạo vật phẩm.\n- Các cư dân thu thập các nguyên liệu sau đây để gói thành hộp quà:\n+ Giấy màu: đánh quái trừ những map gần làng ở 3 hành tinh sẽ nhặt được, max 999 giấy/ngày.\n+ Hộp đựng quà: dùng x99 giấy màu để chế tạo + 2 triệu vàng.\n+ Socola trái tim: đánh Siêu Quái, Boss trong các phó bản level 20, ký gửi vàng.\n+ Hoa hồng giấy: đánh mộc nhân rơi, rơi max 999 hoa/ngày, ký gửi vàng.\n+ Nơ trang trí: bán tại Chi Chi với giá 5 ngọc.\n- Tiếp theo, cư dân chọn 1 trong những nguyên liệu, ấn sử dụng sẽ xuất hiện công thức chế tạo:\nHộp quà Nhẹ Nhàng (Ký gửi ngọc): 30 hoa hồng giấy + 5 socola + 1 hộp đựng quà.\nHộp quà Chỉn Chu (Ký gửi ngọc): 30 hoa hồng giấy + 5 socola + 1 hộp đựng quà + 1 nơ.\n- Khi chế tạo được hộp quà ưng ý, cư dân hãy mang tặng cho các NPC: Lý Tiểu Nương, Bà Hạt Mít, Bunma để may mắn nhận 1 trong các phần thưởng ngẫu nhiên và có thể nhận được:\nCải Trang Buma Rider Mới hạn sử dụng, vĩnh viễn.\n\nĐUA TOP TẶNG HỘP QUÀ CHỈN CHU\nThời gian đua top xem chi tiết tại NPC Chi Chi\nMỗi lần tặng 1 hộp quà Chỉn Chu nhận 1 Điểm\nTop 1: Danh Hiệu: Em Xinh Em Đẹp 365 ngày, Đá bảo vệ x30, 50 cuốn sách cũ + 3 Capsule 1 món kích hoạt + 1 Capsule Vỡ\nTop 2: Danh Hiệu: Em Xinh Em Đẹp 180 ngày, Đá bảo vệ x25, 40 cuốn sách cũ + 2 Capsule 1 món kích hoạt\nTop 3: Danh Hiệu: Em Xinh Em Đẹp 180 ngày, Đá bảo vệ x20, 30 cuốn sách cũ + 1 Capsule 1 món kích hoạt\nTop 4-10: Danh Hiệu: Em Xinh Em Đẹp 90 ngày, Đá bảo vệ x10, 20 cuốn sách cũ\nTop 11 - 50: Danh Hiệu: Em Xinh Em Đẹp 60 ngày, Đá bảo vệ x5, 10 cuốn sách cũ\nTop 51 -100: Danh Hiệu: Em Xinh Em Đẹp 30 ngày, Đá bảo vệ x2, 5 cuốn sách cũ\n\n3. TẶNG HOA HỒNG\nTrong thời gian diễn ra sự kiện cư dân mang các nguyên liệu sau đây để tiến hành trồng hoa hồng:\n+ Túi hạt giống hoa hồng: bán tại NPC Chi Chi giá 5 ngọc.\n+ Đất trồng: đánh quái, max 999/ngày\n+ Ống tre nước: làm nhiệm vụ hàng ngày, đánh Boss, đánh quái phó bản\n+ Chậu đất: được bán tại NPC Chi Chi giá 2 triệu vàng.\nCư dân có thể dùng thuốc tăng trưởng nhanh (giá 1 ngọc tại Chi Chi) để cây lớn nhanh.\nTrồng hoa hồng bằng chậu đất cần: 99 đất trồng + 5 ống tre nước + 1 hạt giống + chậu đất.\n- Khi thu hoạch: nhận 1 - 3 hoa hồng.\n- Dùng thuốc tăng trưởng: nhận 3 - 5 hoa hồng.\nHoa Hồng Ký gửi vàng\nDùng 20 Hoa Hồng tặng NPC: Lý Tiểu Nương, Bà Hạt Mít, Bunma để nhận quà ngẫu nhiên các phần quà\n\n4. MỞ BÁN VẬT PHẨM TẠI NPC CHI CHI\nTrong thời gian diễn ra sự kiện, NPC Chi Chi sẽ mở bán các vật phẩm:\n+ Cải trang thỏ Buma\n+ Mèo trắng đuôi vàng\n+ Một số cải trang nữ\n+ Capsule hồng\n+ Thiệp chúc 8/3\n*Mở Thiệp Chúc 08/03 để nhận được các vật phẩm ngẫu nhiên và có thể nhận được:\nMáy Bay 41 (New) hạn sử dụng, vĩnh viễn\nCác cư dân có thể đến NPC và lựa chọn các vật phẩm phù hợp với mình nhé!\n\n5. ĐỔI ĐIỂM TẠI NPC QUY LÃO\nNgười chơi có thể đổi các vật phẩm có hạn sử dụng hoặc nếu may mắn sẽ nhận được vĩnh viễn tại NPC Quy Lão tại Đảo Kame.\nThời gian từ ngày 07/03 đến hết 14/03\n- Đặc Biệt mở capsule 08/03 2026 có Buma Tiến Sẽ và Pet Kirby cùng các cải trang cũ được làm mới\n\n6. CẬP NHẬT VÒNG QUAY THƯỢNG ĐẾ\nVòng quay sự kiện ngọc tại thượng đế sẽ cập nhật thêm các vật phẩm sau:\n- Bó hoa hồng đỏ\n- Bó hoa hồng vàng\n- Cải trang Bunma tóc xanh neon\n- Cải trang Bunma tóc nâu băng đô\n- Cải trang Bunma tóc tím thắt bím\n- Goku SSJ4 Red\n- Gậy phép của Frieren\n- CT Frieren\n- CT Arale\n\n7. GIẢM GIÁ 20% MỞ RỘNG HÀNH TRANG, RƯƠNG ĐỒ, TÚI VÀNG\n- Mở rương sưu tập (tương lai) lên 60 ô\n\n8. ĐUA TOP VÒNG QUAY THƯỢNG ĐẾ\n\nA. Top quay bằng ngọc.\nTOP 1: Cờ Shiet Hồng Vip vĩnh viễn, Sách Cũ x70, Capsule 1 món kích hoạt x3, 3 Capsule vỡ\nTOP 2: Cờ Shiet Hồng Vip vĩnh viễn, Sách Cũ x60, Capsule 1 món kích hoạt x2, 2 Capsule vỡ\nTOP 3: Cờ Shiet Hồng Vip vĩnh viễn, Sách Cũ x50, Capsule 1 món kích hoạt x1, 1 Capsule vỡ\nTOP 4–10: Cờ Shiet Hồng Vip vĩnh viễn, Sách Cũ x20, Phiếu đổi capsule x50, 250 Mảnh Capsule vỡ\nTOP 11–50: Cờ Shiet Hồng Vip 180 ngày, Sách Cũ x10, Phiếu đổi capsule x20, 100 Mảnh Capsule vỡ\nTOP 51–100: Cờ Shiet Hồng Vip 90 ngày, Sách Cũ x5, Phiếu đổi capsule x10, 20 Mảnh Capsule vỡ\n\nB. Top quay bằng vàng\nTOP 1: Cờ Shiet Hồng vĩnh viễn, Đá Bảo Vệ x70, Capsule 1 món kích hoạt x3, 2 Capsule vỡ\nTOP 2: Cờ Shiet Hồng vĩnh viễn, Đá Bảo Vệ x60, Capsule 1 món kích hoạt x2, 1 Capsule vỡ\nTOP 3: Cờ Shiet Hồng vĩnh viễn, Đá Bảo Vệ x50, Capsule 1 món kích hoạt x1, 250 Mảnh Capsule vỡ\nTOP 4–10: Cờ Shiet Hồng vĩnh viễn, Đá Bảo Vệ x20, Phiếu đổi capsule x50, 100 Mảnh Capsule vỡ\nTOP 11–50: Cờ Shiet Hồng 180 ngày, Đá Bảo Vệ x10, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\nTOP 51–100: Cờ Shiet Hồng 90 ngày, Đá Bảo Vệ x5, Phiếu đổi capsule x10	1	ADMIN HAI DANG	ACTIVE	2026-04-03 17:42:10.573	2026-04-03 17:42:10.573
5	CÔNG BỐ KẾT QUẢ ĐUA TOP LÌ XÌ 2026	https://forum.ngocrongonline.com/app/view/forum/17724161805550.jpg	Chào các cư dân\nĐể vinh danh người chơi đạt Top 1 Bảng xếp hạng Đua Top "Lì xì 2026" toàn Vũ Trụ, BQT sẽ thưởng thêm 1 ván bay thiết kế độc quyền do người chơi mong muốn và lựa chọn. Ván bay này là biểu tượng của sự kiêu hãnh và uy quyền, chỉ dành riêng cho người chiến thắng.\nVà không ai khác, người ấy chính là "trumboms3" thuộc Vũ Trụ Super 3 với tổng số điểm "95933 "là người thống trị và đứng đầu tất cả Vũ Trụ Ngọc Rồng Online.\nNgoài ra người đã đạt được trên 84.000 điểm sẽ nhận được:\n- 5 chỉ số phụ tùy chọn (đã bao gồm 2 chỉ số được chọn ban đầu)\n- 02 Set SKH tự chọn 7 sao - Đồ cấp 12\n- Máy Chủ Super được hưởng 15 ngày x3 TNSM (sẽ bù thêm nếu trùng với sự kiện khác) - Áp dụng X3 cho Super 3 từ 02/03 đến hết 16/03/2026\nMột lần nữa, xin chúc mừng và cảm ơn trumboms3 và Super 3 vì thành tích vô cùng ấn tượng này và hãy sớm liên hệ cho Admin để cung cấp phần thưởng mà bạn mong muốn!\nChúc các cư dân chơi game vui vẻ	1	ADMIN HAI DANG	ACTIVE	2026-04-03 17:42:34.215	2026-04-03 17:42:34.215
6	TẾT ĐẾN – XUÂN VỀ – QUÀ NGẬP LỐI!	https://forum.ngocrongonline.com/app/view/forum/17709569999727.jpg	Chào các Cư dân,\nMột mùa xuân mới đã gõ cửa, mang theo không khí Tết rộn ràng và hàng loạt sự kiện đặc biệt dành cho các Cư Dân.\nHãy cùng tham gia Sự Kiện Tết Nguyên Đán 2026 để săn quà khủng, đua top cực cháy và tận hưởng trọn vẹn hương vị Tết trong thế giới Ngọc Rồng Online !\nThời gian kết thúc sự kiện: 23h59 ngày 06/03/2026\n1. KHUYẾN MÃI X3\nA/ KHUYẾN MÃI X3 THẺ NẠP\nTừ 00h05 17/02 - 23h59 20/02\nB/ KHUYẾN MÃI X3 TNSM\nTừ 00h05 17/02 - 23h59 27/02\n2. HÁI LỘC\nKhi các Cư Dân đạt 10 tỷ sức mạnh làm các nhiệm vụ sau để nhận Lộc:\n- Đánh Quái (max 99/1 ngày)\n- Đánh Boss (tất cả boss, max 100/1ngày)\n- Làm nhiệm vụ Bò Mộng\nSau khi tích Lộc, Cư Dân đến NPC Đào Mai tại đầu làng để đổi thưởng\nĐặc biệt có Cờ MĐTC (Mã đáo thành công) Vĩnh viễn và 100 triệu vàng\n3. NẤU BÁNH NGÀY TẾT\nA. Nguyên Liệu\n- Thịt Heo: Đánh Quái Heo để nhận\n- Nếp: Tham Gia Võ Đài (Thắng nhận 5, thua nhận 1)\n- Đậu Xanh: Làm nhiệm vụ Bò Mộng, đánh quái trong phó bản lv 20 trở lên ( Doanh Trại, Bản Đồ Kho Báu,...)\n- Lá Dong: Đánh quái hành tinh thực vật, Mộc Nhân\n- Trứng Muối: Bán tại NPC ChiChi\nB. Nấu Bánh\nĐến NPC Nồi Bánh để nấu bánh theo công thức sau:\n- Bánh Chưng: Thịt heo x10 + Nếp x10 + Đậu xanh x10 + Lá dong x10 + Trứng muối x1 + 5 triệu vàng\n- Bánh Tét: Thịt heo x10 + Nếp x10 + Đậu xanh x10 + Lá dong x10 + 5 triệu vàng\nSau khi nấu bánh xong sẽ nhận được bánh và 1 phần thưởng\nPhần thưởng đặc biệt có các cải trang vĩnh viễn và Cải Trang Chi Chi Tết\n4. NGỰA ĂN CỎ\nBa ngựa con sẽ xuất hiện ngẫu nhiên trong các map, Cư dân dùng "Rơm" cho ngựa ăn và nhận được 1 Capluse Tết 2026\nĐặc biệt gặp ngưa Đỏ sẽ có cơ hội nhận được pet Ngựa Đỏ vĩnh viễn\n5. NHIỆM VỤ KOL\nTham gia làm nhiệm vụ KOL nhận nhiều phần quà hấp dẫn và danh hiệu Đón Xuân\nNạp 70 ngọc xanh để nhận vé KOL Vip Tháng 2\nNạp 10 ngọc xanh nhận: ngẫu nhiên 10 - 500 hồng ngọc + 2 hộp Cadic Vip + Danh Hiệu Fan Cứng 30 ngày\nTừ 00h05 17/02 - 23h59 06/03\n6. ĐỔI ĐIỂM NẠP TẠI QUY LÃO\nNạp 1 ngọc xanh sẽ được 1 điểm\nĐổi các vật phẩm siêu hot tại NPC Quy Lão\nThời đến hết ngày 27/02/2026\n7. ĐUA TOP\nXem thời gian chi tết tại NPC Chi Chi\n*MUA LÌ XÌ 2026\nTOP 1: Pet Ngựa Thần Tài vĩnh viễn, Sách Cũ x140, Capsule 1 món kích hoạt x3, 3 Capsule vỡ, 3 Con Dấu, 50 Mảnh Khỉ\nTOP 2: Pet Ngựa Thần Tài vĩnh viễn, Sách Cũ x120, Capsule 1 món kích hoạt x2, 2 Capsule vỡ, 2 Con Dấu, 30 Mảnh Khỉ\nTOP 3: Pet Ngựa Thần Tài vĩnh viễn, Sách Cũ x100, Capsule 1 món kích hoạt x1, 1 Capsule vỡ, 1 Con Dấu, 20 Mảnh Khỉ\nTOP 4–10: Pet Ngựa Thần Tài vĩnh viễn, Sách Cũ x40, Phiếu đổi capsule x100, 250 Mảnh Capsule vỡ, 10 Mảnh Khỉ\nTOP 11–50: Pet Ngựa Thần Tài 180 ngày, Sách Cũ x20, Phiếu đổi capsule x40, 100 Mảnh Capsule vỡ, 2 Mảnh Khỉ\nTOP 51–100: Pet Ngựa Thần Tài 90 ngày, Sách Cũ x10, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\n*PHÁO HOA\nTOP 1: Cờ Lì Xì Đồng Tiền vĩnh viễn, Sách Cũ x140, Capsule 1 món kích hoạt x3, 3 Capsule vỡ, 3 Con Dấu, 20 Mảnh Rồng\nTOP 2: Cờ Lì Xì Đồng Tiền vĩnh viễn, Sách Cũ x120, Capsule 1 món kích hoạt x2, 2 Capsule vỡ, 2 Con Dấu, 10 Mảnh Rồng\nTOP 3: Cờ Lì Xì Đồng Tiền vĩnh viễn, Sách Cũ x100, Capsule 1 món kích hoạt x1, 1 Capsule vỡ, 1 Con Dấu, 5 Mảnh Rồng\nTOP 4–10: Cờ Lì Xì Đồng Tiền 180 ngày, Sách Cũ x40, Phiếu đổi capsule x50, 250 Mảnh Capsule vỡ, 2 Mảnh Rồng\nTOP 11–50: Cờ Lì Xì Đồng Tiền 90 ngày, Sách Cũ x20, Phiếu đổi capsule x20, 100 Mảnh Capsule vỡ\nTOP 51–100: Cờ Lì Xì Đồng Tiền 60 ngày, Sách Cũ x10, Phiếu đổi capsule x10, 20 Mảnh Capsule vỡ\n*MUA HỘP NÓN TẾT (20 TRIỆU VÀNG)\nTOP 1: Ra Đa Ngọc Rồng Vip 200, Đá Bảo Vệ x70, Capsule 1 món kích hoạt x3, 2 Capsule vỡ, Capsule cải trang VIP x4, 20 Mảnh Rồng\nTOP 2: Ra Đa Ngọc Rồng Vip 100, Đá Bảo Vệ x60, Capsule 1 món kích hoạt x2, 1 Capsule vỡ, Capsule cải trang VIP x3, 10 Mảnh Rồng\nTOP 3: Ra Đa Ngọc Rồng Vip 60, Đá Bảo Vệ x50, Capsule 1 món kích hoạt x1, 250 Mảnh Capsule vỡ, Capsule cải trang VIP x2, 5 Mảnh Rồng\nTOP 4–10: Ra Đa Ngọc Rồng Vip 40, Đá Bảo Vệ x20, Phiếu đổi capsule x50, 100 Mảnh Capsule vỡ, Capsule cải trang VIP x1, 2 Mảnh Rồng\nTOP 11–50: Ra Đa Ngọc Rồng Vip 20, Đá Bảo Vệ x10, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\nTOP 51–100: Ra Đa Ngọc Rồng Vip 10, Đá Bảo Vệ x5, Phiếu đổi capsule x10\n8. NGŨ HÀNH SƠN\nCách chơi : CẬP NHẬT BÀI VIẾT SAU\nChúc Cư Dân một năm mới Tết rộn ràng, mạnh khỏe, hạnh phúc – Đua Top bùng nổ – Quà ngập tràn!\nĐừng quên theo dõi Fanpage để cập nhật thông tin mới nhất!	1	ADMIN HAI DANG	ACTIVE	2026-04-03 17:43:02.695	2026-04-03 17:43:02.695
\.


--
-- Data for Name: saga_state; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.saga_state (saga_id, phase, attempt, completed_steps, original_password, original_email, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: withdraw_money; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.withdraw_money (id, user_id, amount, bank_name, bank_number, bank_owner, status, finance_id, request_at, success_at) FROM stdin;
1	5	100000	Vietinbank	0396436954	PHAM HAI DANG	SUCCESS	1	2026-04-03 09:02:47.753	2026-04-03 17:44:06.1
\.


--
-- Name: accounts_sell_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_sell_id_seq', 1, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.posts_id_seq', 6, true);


--
-- Name: withdraw_money_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.withdraw_money_id_seq', 1, true);


--
-- Name: posts PK_2829ac61eff60fcec60d7274b9e; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT "PK_2829ac61eff60fcec60d7274b9e" PRIMARY KEY (id);


--
-- Name: withdraw_money PK_599f3eab56751c2880b67e14465; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.withdraw_money
    ADD CONSTRAINT "PK_599f3eab56751c2880b67e14465" PRIMARY KEY (id);


--
-- Name: accounts_sell PK_a846a2d2a9945d55b50e10d7115; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_sell
    ADD CONSTRAINT "PK_a846a2d2a9945d55b50e10d7115" PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict AoRYRQh0JvVyjZNP5kh4eRi0bpGlOLxSKYaVIgahRwaiHdn53l40RRGfntRbTXm

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict NiWGBFS876kX9nNeFSA9lW9GtaZJ8TnlMRJrHA7hqv0vcwJ7cTgwnxfHHc3kzJr

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NiWGBFS876kX9nNeFSA9lW9GtaZJ8TnlMRJrHA7hqv0vcwJ7cTgwnxfHHc3kzJr

--
-- PostgreSQL database cluster dump complete
--

