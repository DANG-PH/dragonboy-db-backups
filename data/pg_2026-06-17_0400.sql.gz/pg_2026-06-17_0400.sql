--
-- PostgreSQL database cluster dump
--

\restrict dcHfpaAGsO0jzAHbCBt1vsxPUlkDjsTYxpuRklVLpyh954TRxg1E9wdGhIR15pf

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE admin;
ALTER ROLE admin WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:4l4wLN7Qq9kZuGRiGAWpIw==$jdR6B7fC42qGNZOQgp5Gxd7y26Asyr88p9eTAnSHpxo=:jPqlMrrj0/v/31Et+CMUg0/im2UwihD5J/n/TtDGMNo=';

--
-- User Configurations
--








\unrestrict dcHfpaAGsO0jzAHbCBt1vsxPUlkDjsTYxpuRklVLpyh954TRxg1E9wdGhIR15pf

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict 8jvfRf525mlcP3CryRD0TlGe7TMLgkN3Xx2xSgQgNJE1hnCnh4xOCNvsxVxqTRQ

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 8jvfRf525mlcP3CryRD0TlGe7TMLgkN3Xx2xSgQgNJE1hnCnh4xOCNvsxVxqTRQ

--
-- Database "admin_db" dump
--

--
-- PostgreSQL database dump
--

\restrict o5R3egXLsSmMhB2Se3CIyOJsJEUdv0Npfmw5fyVnKoVnNWeiZcEeanjIitZevgT

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: admin_db; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE admin_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE admin_db OWNER TO admin;

\unrestrict o5R3egXLsSmMhB2Se3CIyOJsJEUdv0Npfmw5fyVnKoVnNWeiZcEeanjIitZevgT
\connect admin_db
\restrict o5R3egXLsSmMhB2Se3CIyOJsJEUdv0Npfmw5fyVnKoVnNWeiZcEeanjIitZevgT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: saga_state_phase_enum; Type: TYPE; Schema: public; Owner: admin
--

CREATE TYPE public.saga_state_phase_enum AS ENUM (
    'FORWARD',
    'COMPENSATING',
    'DONE',
    'FAILED'
);


ALTER TYPE public.saga_state_phase_enum OWNER TO admin;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts_sell; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.accounts_sell (
    id integer NOT NULL,
    username character varying NOT NULL,
    password character varying NOT NULL,
    url character varying NOT NULL,
    description character varying NOT NULL,
    price integer NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    partner_id integer NOT NULL,
    buyer_id integer,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    version integer NOT NULL
);


ALTER TABLE public.accounts_sell OWNER TO admin;

--
-- Name: accounts_sell_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.accounts_sell_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_sell_id_seq OWNER TO admin;

--
-- Name: accounts_sell_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.accounts_sell_id_seq OWNED BY public.accounts_sell.id;


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.outbox_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "sagaType" character varying NOT NULL,
    payload jsonb NOT NULL,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    retries integer DEFAULT 0 NOT NULL,
    "maxRetries" integer DEFAULT 3 NOT NULL,
    "nextRetryAt" timestamp with time zone,
    "lastError" text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.outbox_events OWNER TO admin;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying NOT NULL,
    url_anh character varying NOT NULL,
    content text NOT NULL,
    editor_id integer NOT NULL,
    editor_realname character varying NOT NULL,
    status character varying DEFAULT 'ACTIVE'::character varying NOT NULL,
    create_at timestamp without time zone DEFAULT now() NOT NULL,
    update_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.posts OWNER TO admin;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO admin;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: saga_state; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.saga_state (
    saga_id uuid NOT NULL,
    phase public.saga_state_phase_enum DEFAULT 'FORWARD'::public.saga_state_phase_enum NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    completed_steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    original_password text,
    original_email text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.saga_state OWNER TO admin;

--
-- Name: withdraw_money; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.withdraw_money (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    amount integer NOT NULL,
    bank_name character varying NOT NULL,
    bank_number character varying NOT NULL,
    bank_owner character varying NOT NULL,
    status character varying DEFAULT 'PENDING'::character varying NOT NULL,
    finance_id integer,
    request_at timestamp without time zone DEFAULT now() NOT NULL,
    success_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.withdraw_money OWNER TO admin;

--
-- Name: withdraw_money_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.withdraw_money_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.withdraw_money_id_seq OWNER TO admin;

--
-- Name: withdraw_money_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.withdraw_money_id_seq OWNED BY public.withdraw_money.id;


--
-- Name: accounts_sell id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_sell ALTER COLUMN id SET DEFAULT nextval('public.accounts_sell_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: withdraw_money id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.withdraw_money ALTER COLUMN id SET DEFAULT nextval('public.withdraw_money_id_seq'::regclass);


--
-- Data for Name: accounts_sell; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.accounts_sell (id, username, password, url, description, price, status, partner_id, buyer_id, "createdAt", version) FROM stdin;
10	dang1	aP9%682X%$pxBD	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	Acc Ok	123456	SOLD	12	4	2026-04-16 18:12:43.73	6
12	dang1	aP9%682X%$pxBD	https://ngocrongonline.com/images/screen/4-2.png	Acc TD Vip	99999	ACTIVE	12	\N	2026-04-17 07:46:47.618	1
13	acc1	uW5.Q(wHwxnmpe	https://api.shophhp.net/storage/51915/12,1.png	Acc sơ sinh có đệ	20000	SOLD	12	4	2026-04-17 07:48:45.504	3
14	dang123	123456	https://s3.hcm-1.cloud.cmctelecom.vn/bannick/storage/imageacc/d09635c35c89f12b4555da2ba8ad0192.jpg	Account hành tinh Xayda, dame ổn định	1000	ACTIVE	12	\N	2026-05-19 17:10:34.502	3
1	DungNguyen1	tY9?t&PB3svUi9	https://www.instagram.com/p/DFZvfnKz3tZ/?img_index=1	vip	122222	SOLD	2	4	2026-04-15 22:11:25.265	6
2	thanhle3	jN0{lo*;<-KcmL	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhUTExMWFhUWGRsaGRgYGBoXIRobGhoYHxoYGRgaHSggHholGxsYITEjJSkrLi4uGB8zODMtNyktLisBCgoKDg0OGxAQGy8lICUvMDUrMC8tLS0tLS0tLS0tLS0vLS0tLS0tLS0tLTAtLSstLS8tLS0tLS0tLS0uLS0tLf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAAABgQFBwMCAQj/xABBEAACAQIEAwYDBQYFBAIDAAABAhEAAwQSITEFQVEGEyJhcYEyQpEjUqGx8AcUYnLB0TOCkqLhFkOy8SSDY5PC/8QAGgEAAgMBAQAAAAAAAAAAAAAAAAECAwQFBv/EADARAAIBAgQEBQQCAgMAAAAAAAABAgMRBBIhMRNBUYEiYZHh8DJxsdHB8WKhBRQj/9oADAMBAAIRAxEAPwDcaKKKACiiigAooooAKK83GgEgFiATAiT5CSBJ8yKQ8f8AtUw9pzbfDYpXUwysttSD/wDsPr70AP1FZ5a/a9gz8VnEL55bZ/K5P4VaYP8AaVw64YN4of47bj/cAV/GgBvoqNgcfavrns3EuL1Rgw+oNdBiFzlJ8QEx5HmOonTSgDrRRRQAV4vXQqljsoJPoK91wxSK6taY/GpEAwYOkj+9AEIcWIGdrLi398a6dSkZgI/4mrK24YAgggiQRqCDzBqtwz4nvFS4i5ADNxWnOdgMp1XeTvqOleuHJ3Vx7I+H/ETyDE5h6BvzoEWVfCY1NfLjgAk7CqqzhDfPeXScm6ICRpyYxr6RB675VBllbxKMYV1J3gEHTrpXWl+6cO9xLeHyd6lxWY2wPAFbx5yvMgMsHXxHTQ0wUCCiiigYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUu9ruytrGpMKt5B4Hj/Y3VT+G45gsVFAH514t2edCwUFXUw9s8j5cuh6EGQYpedY0Mgj29q3zt9wgMn7yo8VsRc87fU/yzPoW6Csi7SWQCrxodJG4JBiRz/458oiKjhuLu2Lgu2rjW2HNTB9D1HUEEGtZ4J2pPE7OVGFviGHm5a5LdA+JY+648LLy0YbCMkuXxoAZjmenSvmGxL2bi3rTFXQhlI5Ef05EcwSKAP0h2e48mLtJdUFS0qyndLixmtt/ENT5gTVtWSdn+PgYlMRbhbWO/xEnS1i0jMPJWLKZ5reJ5VrNpwwDDYgEehqQz1VTiXe07MLDXcxEMpWRsCpkggacvKravhMUACnTaPL/wBVV4rGJbxALH/tkaCdcwMQNZ/vUrHYnLbOsMwhesnn7TJrLsXeAv3r4OVF8BtrOa45+EMRz3bSWGs5aCuc8poHGOOYcIPtrZUsA3iGin5v1zEVX4ztWqvOcAACEHiLTMyBrtEEaA9daz7EY9LFh1YH94cjPv8AZ6Ke7WfmIgtHMkEnKKj8Mf7JREbyPfy6aCpqFzNPEtbGgt29siQlsjocr+Y1GQeXON9dNZXCe0K3bkrczgQH8QjxafDyiQZjl1mM4z68p16jb228/wC9e1GoOsjZtiPMEQR7VJ0yCxUr6myHiNoGDcUH1HnB9NCPY9DXe1dVhmVgw6gyNN9R51mvD+0NxQFunMv3wPEPIgfEPMDNpsT4g7cBvK2bKQQwVwQZBkESD0hVqp3TszZCpGexb0UUUFgUUUUAFFFFABRRRQAUUUUAFcrl0g6IzeYy/wBWFdaKAI373HxJcX/Lm/8AAtXu1ikY5Qwzfd2Pup1FQ+J8fwuH0vYi2h+6WGb2X4j9Ko73bzAPp47i9e6aPo4B/CgBsu2wwKsAQQQQeYO4NYZ2hwWU38M05rJIE7sohkM9SpX/AFGtU4X2kw10gWb4af8AtXCUf/J3kMfQyNoIpN/abhcuKw+IT4bym22nzWwxEg8yCR/9dJgZIRBottE1IxlmGYdNB7VGxFuADSEdreLZJSTkYgkfxKGAPkYYiv0J+zvjJxeBt3GjOCyPHUHQ+UqVMcpr853NVnpWo/sd7S4fD2r1nEXktFnV1znKDKhT4jp8o3PSmgNgqJxK/lQ7z5DUxEgfxESB51JtuGAKkEHUEGQR1BqLir+aUQZm68l6EnrPrt5UxiRhMXfZ3xWIuNlUugsgA5CrQduenvpqai38a5K28IqLDFy2TNoN9ToCTzOsSNOVhx0XVuuihStwldCFgk5mbU7wxTSeXTVXTG3LidxbULbWe8eT4zO4C65doEjlQtbuxkqeFpXK/H4K45C21zFmYm6B8RzS0RqdTvtoRO9VGJZkbI/Lny05+m31pjF1hcEnOEhcpJAgDUtl5hdQBGUm2Pnqw7NdlzjWe+6zbUtbtliQGYaNcCgeIKRA1AJnpU4tpeLcp4eaXhFPCF/lDMI2ykiPptVyjA+vQ6H0g7H+1af/ANPxJU2wSAP8M8sxG7mDqdYNUXF+BoZDhLJQeFgdydiWMArPXU7mDFPiEnhWloxc/dLiqCBJj1nrpIrrwTigs3VRwMrH4WEgFiOWo1In1/m0k4VyRqPEsqQZ+L8wDvtzBqk40w74HWIBPI+3nT30K14GmjUuB4tmhCSVyypYAHwwNY0IMgj/AJ0uKX+yd4XFLnLmhcwHJolzHQnSf4fKmCqUdJbBRRRTGFFFFABRRRQAVzxF9bal3YKo1LMQAPUmulcsRh0uLldVdTyYBh9DQAjcf/abYtStgC433nOVR6KJc+hC+tJGP7cXLxPe4lyD8lsNbX00ALD+YtWlcX/Z7gL6kLZWy3JrQCx/ljL9AD51lnajsBewZLN4rXK6Jy+jjdDPmRtqTSYirv8AFbS6pbDeoy/0NdsP2hQ6MrL+I/D+1UN+w9vRhp1/5rixFKwDdi8cpQsgW4BuCY0qC3aIlBaYuEDi4FJ7wAhSsrOq+EkQNNdjS6t8g6b12wzLmAPt60WAkcQxCu5ZdjG/WIrheuypFfMYsEHrXF2I5UAeFmK+5a9NOmm9eVUzrQAw9l+1uJwB+yfNaPxWmJymdyv3G8x7g1t3CO09m/hVvYbUTlZSssjBSSrKD8XvrMgmRP56uqAutfcDxC9aD9zca2HENlJEgGRtzGuu+pHM0wNc7YcWSzbZWuKtx1IMtrHPIoB1ZjqTHLeNE/G9qsPbRbeHR3gCWICzBncydN9omk6zaLmWPqT1qZhMKbj5RovzHoP70XsVukm7svezyYrHXLdi0AgmcxlueZnbkddTtMKOlfoDC2BbRUGygKNANAI2UAD2AFKX7POD28Nh++aFNzQSYyoDoDOzEyx9gdqZ7HE7LtkS9bZonKrqTA3MAzFMmopbEuqzjqeBXEAq255BgQfaSDy2FWdVnaE/ZBcobMy+Exrl8XP+WhkmZ5jLmTFlcwIuCTAgSOY1J5gb9Kp+NGb/AFhdfcyB+ulWnH9MTbITJAMgRtNs/LpsDVFfu5rjGefPoNPyFWxOVUerXmaD2ClkQmSQ11p5QXcQPcj/AE07Urfs9tFcMJGpAM9JklfYkn/PTTVTOlT+lBRRRQTCiiigAoory7QCemtAHqildON3tTK67CJy+h5+8/0qE9182fMc0zM/rTyp2KnVXIda83LYYFWAIIggiQQdwRzFebF0OoYbETXQmkWmQ9veyBwk37ALYY/Gm5sz8w5m1/4+myDi+HBhmTcchzrcuPdt7GGkXbGJy7ZjZZUM8szQKyPiN2wb5fBrFt9e6Lr4TzCgx4doHKY2iosQrC2Oe/0rnfUAaVb8aw+fxKsEAh9tCMsAx1DD9CuHGbJYo42ZVM+oJ/IfnQBWi4zwNzMDzrtetlZDbjzGnX3/ACptwvC1w+Es3WgvdzXSeltVhFB/+wP6x0FRexvZ397uG7eE28x8P3yILeqiVU9c/kardVKLk9ixU22ooWnR1ILgiQGEiJU7GOh3HkQdjXq4vzVM7SYnvcZffrdYCOYQ5F/2qtMPZjsz3o726JAMIp1BcmBPUKd/QjkZcqijHNIIwcpWQn3LxaBFfF0MVf8AbbALZxrKoCqVRgOQ8MH8VJ96psVYa3cZWEMI06FlDAEdQCAR1BpxkpJMjKOVtHQXNuX9KsrPFLSLlVWM765ST1kTVN5DU/rnXOCDlI8R0AGpk7AAbzPLyqREt3xPeOFt2gbjmFAAZizHb1JPSSSa3D9nvZL9xtF7kNiLsZyNkA2tqeg3J5nyAApf2Xdgf3QDFYlf/kMPAh/7Skaz/wDkI0J5AwOc6PTSGFL/AB67nuLbDMuUaECQXImDpuFExIkOauMdihaQsfYTEmCd+WgJJ5AE8qR+JcVKkw2YOCSYjKZObTcEbQfIaEeJ76EJyUVdlH2gxINwtvHP0P8AYT70q2hnYIPmME+u5gDYCfpX3jPEM7EDbSdfp7D+lX/7OuFm9fF2PCjCPMggsfQDSf44q3ZHNSc5Gs8Hwvd2lUiDuR08vUCBU2iiqjqJW0CiiigYUUUUAFFReJoxtkLv5cxzFRFxJsWgG1czlWdh5noKBN2OuJ4UhQqihTMg+c/lypfNhs5tx4gYIGv6HOam2OK3A+ZiWXmoA6aZfeOfWpd3jyx4FOY8mEQOukz6TTKnlZL4Th2tplbeSY6eX9fephrjgsT3i5ojkR513pFq2E/tBwjiRk2cYWXX7PLatn0BKGT6sBWTcZ7POjkXQ9u4xmHUKGPPLlhT6rpX6JrlisOtxSjqrAjZgGB9QdxSsM/NuHtPbLI+qOIkeKI2Mb6VI/drgwodlBQlgp6ZZlW6HLMeQ8qeO0nY3E22N21atm2NStgOfc2nYkdItzvMVXdkkTE279piMyuDBmMrZQUOk6NbboQWB0IBFc24q5KEczsUfaXjuZVw+QBLKhUZZkg20kEHfVTBEdK0jsrwoWLaWwB4FVT/ADHxXGH8xYfSvnDeHWcThbNi4C9pdIbfwfAsjxDwjcEGF1Opr5avWuG3LeHe79ndJ7ktJZMuQd27bFBKhWMEbGYmqZRzxVti1PK3cyLsfw1sZiANRPiJ+6Dqzeo2H8TLWt8VxVjA2s7ALbsroo3ZiCqIp65Q8zsCCdBVX2C4H+5LinuCPtnRdCfsrZhSANfEZMDeFqP2fxYxvFLq4i05GGzNaVoyo4ZVL3F2NwjLlMkAJpJGapSSnLyQk3CPmxXt8NxGKu3MbiSLS22Q5WUyVEMLVtYnYgCRqWjcmJ3A+z5e9dxWMs5iWJFomQzOZZniYQFsig6lpEeAitG7QuAyE9Gk+QKkT/uI/wA1U3C+JLZw7Yi4MttS7s7aEyWJRR6kARuZ51W6ksziiagsqkzK8RhWTFXMLZtM7d69tVWSxyswEddNZ6amtd7Bfs8XCsMTiYfEfKo1Wzpy+9c6tsNh1OZ9nbXEr9x72EtXg15izXE8AOZixAusQMsnYHWBvWvdj+GcStkNjb9hhr4RbzP5fajIB/pb1rYjMN1csTiFtqWYwB+oHnXu44UEkwAJJpH7ScaJO/VQkTlkeF/WdDMiNIyksWKUkldkbtFxss5WStxdlHLWdOpBCN/EM+hyqQjcY4uW8IIHIldvRf4elfeMcQzEKCSVBUsTJgHRAd4/RnU1a8H7L2LuHF27cdGaWzSoRRJCg5hJJENvsQNNzNWjuYZydV2QsYPAtdYIvxN15Dmx8gProK3LshwoYbDqoETrrvEaT5zJ9WNI3DRhMEujF7uxuQyj0WRly84k7ekWPDu2VhW/xCpOhLocp9SDMj7zHmdddFKTfIsoxjDdq5odFLdnjDPDpdDA7ZQrIfcSf91X+FvZ0VtpG3Q8x7HSoJ3NdzrRRRTAKKKKACk/F4vvHL8jt6ch9KbyKRAhXwN8S6EeY/pzHlFNFNZ7ExWrstoHU/2qErairC21JkI6k7CYo2xG4/GrhWkAjY0vTUzB22Ui4zBUA1JPLWB6TrSRcmW1FVt/juHV8huqXMQqnMTIkDTmQQQOc1Fw+KOJaBdVVIzBVILMv3hPy6jUggzsNCWSuXlIvGrti7jsllAt9UY3LwHxKMo7phs4LEb6jI0QdQyYzDmxau3LR8S2zAgbiSdtz0Gw96zzshdnF4kkyci6nmC7kkn3GtKf0NiUv/SMeox8Nsdy5WIV2zrBmHA8SidfEoJgzABE134jlvNbz4cHu3zA3EtvGmjIRclTOXWD8O3Oq/iTm53b22IytoY+bMAYkbhRc9iRzqv4F2yXEO1t7ZVlJ8SkFSATqQYI9BmrHGTknlNUoxi1mGVcQCSoYFliROonaa8Br0mHVQdAMufbYz4foZ/tEGNtNJW7bkEBvEBEaw0QwIBmD97zrjf4t4siAA7Z7vhWYmAJDMYExoIIM1UnKOpa0pHTtDjBbseNsxMnxKDKrq/hWNCPBpzuD0pAw3E7+Ju2rjlCyPNtco7pAo8TC2ZGni1Mt0I0qf2vul7iYVLhe5dIzvppGsADZUEtA5+YapFvArOW2uUBRbnoojNrzJ8K+zUVavDir7vXt7jo0+LN22Wnd/r8sbOyfa6bZXFMxfNo4tyCpAgEWxoQcw2iI1ptwXELV6e7uK8bgEEr5MNwfI1jvaHjAsAWbXxR9B1PnXPsX2jPD3drwz98BIElkjMVYgD4STBG8QRtB04SVWrDNJacurM2LdGlPInrz6I0ftZxcJNtWAdQCAfmfdVPlAk+oO61muJ4h+9X0CglrjqrFSdFzarOmoGbXlBqfxjEtibqolwXJb7N10JNwy88oG56ZTppV5xbibWx3VsZTsI2toNJHmViB59IrUtDn1JKd23oiNilw9tGw9uxbO0g65THzNOYncgSDHMTJ9YfAG4MzNlCiASNhEQo0CoPKBp61GwuERR3tyQo+FZ1YnmZ/MzMmdN4nE+P+IA7HZQNhtr1PnTS6Fbkt5ehMv4Cw2hfMOcr+I/GpPFOzVm5aIsoiEwymBqeUsBMEac96pRiM58InQHT10Og5bjz6Vf8HvsEyuCCDpm0npy6idOtKd1qmFJxk7NCLicNfwbzJtt95GMHpJgT6EEU39lu2NxyLTtDnZgQA3U5YIzASSNjuOeW9uW1bdQfUA1mXF7D27rP8MuSCOTyT4fcSKIvOOSdF3T0N9wd0vbRjuyqT7gGu1IXYvidy61oNpl0ZQSYi2xiJgLsQIO41kRT7SNkZZlcKKKKCRzvhsrZIDQcs7TGk+U0tqhRCcSpZiYST4hE5jm3yzHWmiofEuHreABJBGxH4iOlBCUb7Ckq+KrG2KjcQsC3cKgyBt9BUXFY8Wke4dQisx9FBJ/Km1coTyvU7cV4kLQAgkwTpGgAJJkkCduvpqKorvFb+IWEzKsMAG1MqSCSf8MKNRm5RXvh1xiwuYseK4rAIBpA7snTkBKjXfz0r5xPGm5ZMLCEjIoOUZVMZm6qW5beEeYoSCUrrc4cVJGHVrVzMtuFTLBDNkPeXWEanMTERBHqK+8E49GW6Z11LKTILAbpOVjEcp3ga0q8V4mVVgrs3UsxgR8qARA9BUngF0G3EyZMDnAgajzIJFTyoz8aSd0ard7RqbYy/E4BDLqMsqHuA7CAec7jfWsxszhcSjGVtsrWsxOhUN4T10cZZPIjrV12ewt7LiVCk5lGTUbkuSokwCQQY03k7zVxx3hdrEWYiUKgrGhCx4SvSAfoawV6jWaL+nZ/vsdehHOozX1br9dyN2ec3sNbYc7l5vpcuhR9CPpWbcHxV2xcN+2RKuR16yD5EH8607sthe5sC0GLZHcSdD4mz6+cMKUONYI4O+4ZM1q+xKEdSSxtkbSCzQNyDz1Alg3DM11RDHqeRSXJll/1usA3LMXOqNB/FdR/CZFUmO7aXipWwosr8zTmY9S1wganfTXoar7uIwwPzT01H5xXjD2zibi4ezagtu7AsVXTM0nZQOm+g5itvApw1MCxFafhLvsVgzkuYx/ExlLc/N94+haEH+brTJYSABv59ep9zrR3iJGHtjwWkgeQBUCerGcx+vOqi5iyt/LsrnLP8QGnvuPz2FebxVR1qjfp9j1GEpKjSS9fuKj3ZvXbrajO0T1zGPYAflVrwHhRxOe/cMWUBYk6ZyAdAeSiNT5QNdRTcIwRv3Mk+Esx9ddT6ARvzgc61fBdn7Pd5CpKkCVDMo0iJCkAkQNTrpXbrV8kY04b29EcGhhlUnKrPa77so+A4PuL0lcqC01wHX4dNzvm1Om/hO8g0Yde8uFmJG7uTqBtpHOPCo8tKs+O2mS2wB0HgcnQFGZDMDmZInb4thS7j8UUtuB80A+gMwP1yFWUZOcbvcz4mMaclFbbny/xE3XyouY7BRooUchJ0WJ8hE1O4bwlEzXMbaHeEwqFgwCCJJCsVPvO3nXLsjlW3duKM90EKQIDBIB8MwNTyJHwexd+x/C1Ki+3iJ/w5EQOZywIadPbSAYE2+RGlDM8z3IFpLmQC3h3CB50TKMoJIygROgXahcWxYoyEFmAyOIIUTmdgdgY09qeKicSwIupEww+Fhup/t1HOoNGvKKFwqpJUgrMNrOU67/Qj2Ipe4zh4c7wTm085n/dP4UzYS0xBthMiCQZ1JYaGCCIhhvGoAiOS7x8yinoYOuuvl6rRDcz14+EgcHxmS+pDlQ0qWDZYIBIJPQQywfvVq3A8Y121Lbg5ZiM0AaxyOsEciDWJLfh1I5Op+jiPbT9TW2dnyf3dAVCwI0mDB+ITqZ3k7zz3M57hhW2rFjRRRUTUfCYqn4/iXtWT4tWfKDzgy0aARsV9POpvGMF39l7WbLmG8TsQdp2MR71WcSNmxh1w9ws/hAEHxafNJOgnYe2opohN6MXO9JrxjCotXC/w5Tm9DpA8ydAK7Y0pmYponIHTSBvUcW1vkBiWRAXYDmVKhQx2nVjBjUA8qbdjIk27IXMV2gRu7Ri0pZILBW+IES8DqgzDlJArpi+L4e+VCkGyrKotoR3jgEAsRqwtqJOX4mgxvr07SYpWjDYfISzfaMkEA/dkcgT6kmdyZkYaxZwFuMqm6wlRrqSPiuAgFVHmdgeYNVzheNrtfn2LIyvJq1/x7lV2i4WtxlZbfcWkX4ri5ZJJnfUiMoHPfSKWLeZbgVPESMyEeGdWESYjUEa0y4Phj8QvP3uJLJaLK8BfDcBEogUlcsFYYTOu8ay7XZXD2ibiPeIUGDdBA01LIFRJ0nXxdYNRhOFGKhdu3f1JSw860nKyQ5dn7tlrAt23BhYPIk/M3Q6nddJMVHx9pLFo5GZFEkgeKZkmFIMEmdFjes8x63cLezoxBMsp0nMujK0aFhr6+JYgy15c4o2LRbjQARoi6hWG5M/EZB0IiCNDua50HJLI9HzNEcVGnfOtVyL3s88K6CM0ByIKnMZBBJJzfCvi89daj4niVq6rWMXbgNoQevIhuR5g6HSQKWy19XBRjIMCNQCYjqyzI0Gb6aVJ4pxPN9liUJup8RRlIQdc4mNflgidNTAqjEUJRmnT59C/CYmE4NVOXo/nQrOIYLFYd8ltTfRv8O6BMDo5+Qj+LQ7jSQLfhSfuVsn48RdMHKJZjrFu3PyjUzpzJIA0X7HFngqlyBrGaPaTGh2kgc9BMTIwnH1tAlA73Svid4WAflBLEqsj3jUmKliFipxUJLTy5/oWG/6dOTnF68r8v2MeCsNbWLhBuMZeDIB1ORTzAljPMnoBULjVq2lt2bnsNNWOoH1+m/Kl/h/FMXdZnt2s7R8XyqOiiOfrJqdewN67kdrgYHSW8ATWD4dY1Ebk/U1gjh3xlxJJfNv7OlPE2oN04uWnx/0V+GvFMrLCsvzADmT4B/DGkc49K0Ds/2oN6U7k94oBOVhBBmG8WqjTzjzpe4b2XZiMzEmEJS2Cd21UkAkkAMxIiNJ3pwwnZu8rK9u2qLbzQCYa4GCyAJhSSJloPhUGJJHYrQi43jutjhYaVRS8ez3OnD7ly4Ha4mWSNIMQR8Ou8COWsn0CX2lw6IxFsjJI8I1yk9B93eOQiOYAauN8WZF7m0s3m5MDFsEwGddzJ0C6TryBNVV7gllpaFZGbwuyZnfqSzGSR4hyk6QIE5VJwkp+qNs6aqwdP0ZT9mMUqMbRlTd2YTuBsY11B0jnWn9jro7juwT9mY8RkkHUE+5Ya6+Gs44/wBnzhVW/ZYMFYECCMjKQRpJMGOu4A51ccO4xbdleziBbuXEIVC2oc5YBTYrIMSNSdJ0jdnUlmRzoRdKWSRptfGYASdAOdLdrj94Bh3IaM2UlsshSBqApEnU8p6VG4jjr9xXUsoAjLAKq4O6uA2cHcaEDUaHUUrmi6IAuW2bO5Yh2ZocBkGdiQJghT4gNwSfpSjx7ib5LneALrqB8pmCB7/maYsbfWz9s4zOdEBgkaHUtAMb+ZrPe0eNLtB1MlmPry8uZjyWpQXMx1p30OfC8Q1/E2LYGj3banrBdZ/XlX6NtoFAUbAQPQVin7I+D99jO+I8FgT5Z2BVR9Mx9hW205bluHjaNwoooqJoF/gOGvWBee+xyiTvMxJZxroD9aW3vtcY3HPibX06AeQH5U78aRmw94KJY23gdTlMD3pBsXMwB6ifrU0Za3htE7jWq83Ctu4Ps8wZ/CyEgS2bvJCtl0IJJ022ymbFDXtQBJgSd/ONpoZWnYV2tqtxmW6LlzICskaAFjmJGhjUxpEedfRhHxNvJGt0RcYMyzmILMxBBIgIAu3h1kEipt9C/wBkgCpnyJ4NiAGJnYR4z0YSuhgtLxNw2AFXRTCZh8WYxmgnTMEIYE+EAMToNcteUnJRibsLCMYuU+x47HcKw+Ht3VtSZyTIOZ0ChgzAgEqc7AwIgR5Vd37pY/NlMTy2IIy85nmI3mdBSXwN82LZlIDLblNDlKlvGQkg5SXYqpOgy60w4TGXHYgq9yDspVEAMEZs0MXgwUzON5jSqa1Kad0y+hWhNNWKHtugKJDDxOSuiqQqAg5Qo65c0j516RVb2d7y+RatqGABlpyqv8zKDqTtpMn1IdbXDi91bl0DKvwppvBUEoCy6AnWT8u0a9OIcTyyiQWXfonrG7RByjqJgETZSrytlitSmvhouWectEK5OXIQ5ZycwAgLEnKzaZh8p0Ikg6ATHrhPBGxn2l127gEZBzvkbueQtzMDnJPOT5w2FF293ZJytrcaYJURm1HNvCgiIDGNqZ+IY9bJQEQh8IIEBSNl8tNh/Carr1HQVm7ze76LoizDU413eMbQWy6vqxY7RdmcPbZe7DIbhiFYxAAHOdczAzpoK58A4VbvIt0KudLgzabrCMR7BvzHOpvFr5a6pJkBly+hckx7Ktcuyj5C9rqltx7DK/0IX61n40p4eWu1vy0auDGniI6LW/4T/gt8agtnNbUAvAZgI2+HMdhueUnQCTAquuk7FSQZ0UfF1LNoBPTfbbUV64rxNFIBad4GvuQBqekjYE9TXnA4d31KlF6sfEfRRy9SD5Vzb80u/wCjqKNtG/nmX3ZztA9lyLi3DaaJllYqZPiVQx011A12gEzL1hMWl0ZrbBhzjkehG4Pkay6/gmQZp286EuXFIdWYEbMpII5wSNY8tjzrZQ/5F01lmtP9mWtgFN5oP9Db2r4UHuo8n7Qhd4GZAxCyDmhk7zQeeupqpBVn0Qqo3gOdevh0aTBzHWAuxmuTdojet91idplbyrJVhsXtiA41PwwdoE6i2Xs2uRXbEFrUAlg7wV6jxENP9edbHJV1el39zFklRdqmnQoe1l8JZRFcjMwLLqTl1ILEyQMwGh/pSi1oEyDqNvl26Eajlr5CnfjeDtXpyBgx5sQQ8CBIA8GgAlZ8wTrSbj+HPbO5Ecm0H+r4T9Z9Na30IZIZTjYuTqVHLkR+NdoMS7IO+YZOSEpJ08TQRJI5bDoKs7HaS+1sAkSR8RHiH/8APvFUNzDS0tI8uR9+YqRh7OdgqeJzsqgs3sq6/wDqrbIz55BxDHQrMPETz1MzGpbfYb1UcF4bdxd4W7QL3H5nYDmzHkon9GBTvhOwGIxBCu6WV3bMczkDkLYOn+YiNNDWldmuzdjA28lldTGZ21ZyPvHp5CAJOlJy6F9KhJ/Ufey/ALeBsLZTU7u2xdzu39AOQAq3ooqs2pW0CiiigYUqXeyZR/sWHdkklX+STICQNV5Qdup5NRNKvaTtAlyw9vDXYdiFzAEZV+YgxzGgI6yOtNXK6mW3iKrtBY/dmCTmJUGYjUkg6dNPxqhvcYKGCjE9B+G9Vp/+O5ABuAgc5KkE/QGSanKjs2bJIIGx/XWrlE50p3d0eLXEylxhMGM0ATAckuIIMAusk9elQeNcYzsqoc7HeRAA10IG/rpMic0KRbYvDt3ZUSs+R2mT71TWeHazsWIRSQSQWMLvy8QNQ4cU8xZxqjWS5ZcCtKqQCO+vtDMpJPMs3lChyJ0kAc4pvtgKAqgBQIAHIVUYru8KLZVYthoaORYQHYnUmfDJ18YrpcxpbQQAee/0rjYrFKTO/g8G4R8+ZIxWKLHurZ8R1ZvuL5fxE6D0Y8oNLjoQFRoo/RJPrzqx4NdUoWVlNxvEUmGUfKpTdYWJHXMedLvaC6YYDQkn6mupg4KMLvucjHzc6ll2PWEtMF7wXMhuawQD4ROWRBOuraEaMKL/ABllU23Nq4saiY9PA22v8VcMdfVQVSykLpmut4dNN3za+igV54dZuXfibKo2yqRJP3cw+EDmAJzabGeGlPE1nKPP/Xfc9E3SwlBRnyXr29ynx9y9Ga0HIE5VZWkZoGUdRtBGu2/ORxHEMiWbqZhICkASSLgDBYI3zcv60xDh6FltoDLTmYkkqvzQT8JM5dI3J5VVcRTvLltBAm+p9FUlmj2Brs4fDZYOM7bHCxWMz1IyhfR8/n8ldwvi9q3LNbZnnmw5cy0klh57RV5h+06sfjtKfuglz9SF/wDH3qZxHhtm9q9sE/e2P+oakeR0qpfH3rBKkeEE5CPCCs+HXVc0RpA/rXPxWEyLNFX+dzqYPHRqvLLR/PsWTY17myuyz93IvrLwG9pqbbbTWB+P4wPyqobiF8gM1piDsQV/IsIoXHudCjL5nJ/Rya5E1b+zsR1/on33Rp1AYddPxNeOH9rblpLuGyhray+h1yNGYAEEGHJO41cVCyzqfrUbDYcDEM0690wbzl7eXTlorfSrcLVdOTkt7e5XiqEakVGW1/YeMPbkzGm9SbltTy/pS1wXi7Ady2pA8BP3RAyn+XSPIjoSbbC4pmMGvR0qiqwU47Hla1PgzdOW58bhVotJtofVVM+uldu5VFEKFUkgQABIAkac4IrsximHBW7eGs57jqQxDTuJIEBOZ0/rVhBRuLOCcW7iMsAhh+cEe4JHvT9XHDBCoZAuUgQQI03FdqGXQjlQUUUUiYUUUUAcMfhzctXLYbKXRlDdMwIn2rJcNezJmG0VsNZ9xP8AZ7cd2Fq+qWSSQpUkrJJy6aQOR3+kmcGluZsRTlK2UQrV2bhPyztynr/zTVgcQTrVT2j7Ntggoa4rMSMoWZKjdj93UgDedelSuFCLZPP9f+6tdmjFZxlZltexAGh3qvxzwA41yMr9fgZWO3kDUS4GclgdvzHL6VXX+JsiEMCGacvKNpIPlI94qLhdWJRqNSTGxsZYvA2ywIYEESNj5gz78t6VrrYjCt3aj94SYUp429GRNQR1iPyHBuP3FKm20BVygGI2Er6ABduZWOdcr/a7E8wFHUOxH0CzFcapg5xurZl6HoqGOhK3iyN8nqWxfFPAbDKF3+1ZFg+jNmn2rhxDDvlBe4hYMpK5mYBVIM96wDE7iCD5EVVJxVm8TYi0BzyhmNdGtPimWLbC0DJZtM3kAd52nz35GjDqsp5aat13fsacVwMmas7222T7czjwzAtcvd9ckoCWt5iSW18LCZIUDUdTB2pnOICg+VRsSwn7RQp6iQPIxOnPmaBhV6fif713qdNQioo8vWrSqzcmTeEcStICzlu8eCfsrug+VdE5D8Sx51UYO6rYgQQcodvMGVXUbgw53qeMIvn9T/euVzCFTmSM0Ea9DBIB6SBp5CpLQg5X5E7PXm5bLQBvOkiQZ0II5ggkVHw98nRhBHL+1WvDcMxYMfhGo8zUZpNNMnTbzJx3IN3h1xkzWbnd3ASCjeJDHymRKjYgqBodRrov/vGJVitzDgEbwSoI6j4gR5jT8qe7ltldmCllaCQupDAQWiZIKhBAk+HYzUPiGMshTmKsF1KnUrG5KHUR6SK4lXDpO2W/Q9JQxTavmt1Fpb7ECVA8s0/0r7hBo1z7xEegBC/gzt5i6OldMVjMI8Kt7Kz6DfnzY3FMD3HQakVE43xK2Fy2WD5REqQQJPiYsNJk+7EVjWHmnZLV6bM3PE02rt6LXdEnhcvdtkfxN/lAKz9WX604YPCHfalXsBfR3dXUB8i5QCSMiGCNeYJUnrPQCHomu3hqTo08j3PP4urHEVuIttvQ8JhhzM1YLdRk7u4gdAZiSI9I9/rUNWrsgq+5UkkWWExxBAgBNAANAo5RXHi/aUWLq2+7LTBJnkfuD5j9Nqj4cAsoOoJAP1q/NkF5KJ4QMrbtrMjbQbbHWfKhDd2tDvRRRTJhRRRQAUUUUAZX2l4PjLuJZ7llnJMKUBKhdcoBG3mTGs1Du8FvWcovKbZYErqD8J1mJHMH3rYKWu3nGreFsB3tpccn7MOsqpG7toTA00GpJVRqRVnEaMssNF3dxAvcStWBEzpOpHPzYgT5UucTxQvEXNQonIZI0+aRE5PAdQpOZYBMEGu4nxTvnzXAHI2LkqADEhLdplVAY28W25qHevZzJaTHykAACAFCroFECBsKjKE5c7EacqUOWZ/PnMmHElpyr5eEToNdF3A1nXXUzrmrrh8P3pRB4SSSzH5V5GD5A+pIqPhuD3LgzLaLDlOgPmC2n1pt7PcLa0hDgAlsxA2GgA8pgT71ZF2VkV1OrWv3OdrDIMoW2gCgAMQCQBpqx1nzrniCQSVcgc9QRPlvVrxKzmWFge29U74bJ4nbQcgN/L9damjO7kkKO7DZp8/fXfy968txEdCNefT+9eMN49ToBoB0H6/Kvt7DDYbnpQIl4HEhgYmeh1+lS5qiv4J16if+KlYO+csEmRoZ/vSaJJljbtkXA6wfJtquV4hAGZIHkZiqrBPmqcdarl5l9NtbEs45IkHfYc/SK5Yq53qPbZfC6lTrBgiOmh1PpVf+7qrSo8R5T56mKlNeA0/vUMqLM75kJbFq6GRkUMnhaFy+hU81MzzAMjcGlTGYI2XysAQRvyYGR9CNCPOmriNksAyM9sk+M2wrHLlPiysrAxCyYkKDrpSzx3geIJzree8NQdACsfKVUaRP96si7rKytqzUo6HDhFzuL6XCxyKwZnnUL4pDxzMFfOdK0bhfGbGJE2bgbqNiPY1l1u3ctavbaIymTkDeeULo8ZPHJPgBqb2exgw14NfNxrDHKHBIZdiGgGO8UbqQZEwNVNUtVL2l28/c1RdK14v7+Xt6mqKK6CrLh/Beb3RcUgFWVQpg9YJB5QRFWVrh1tdcs+uv4bUE8pXcIwhLByIUbeZ8qvKKKZJBRRRQMKKKKACiiigApV7eYS7cRMloOonMQuZ1mIy8wCJkimqigjJXVjKMJwq6QALd4AcgLg+sVLxXBe7Aa9Z32Zxm/EzB9a0yipX8irg/5My8qDXI6VonEeCWbxzOpDfeUwffkah2+yeHG+dvViP/ABinmKnh5chAvzHhifOq2zwi7fuKgZAzGJJgAf8ArlzrR+K9jrdwg2n7oxERmB/EEHzk1XYHsRczA3bqAc8gJPsWAj1g1JTIPDyvsLd7shfw5m665CzBSskkAjKTyUsDMSdqtcD2bumCllv5nIX8G1/CtCwmHW2iouyiBOtdag5svWGgZfi8H4mtt8SGDBmCOn651VX+Bz80jpFaBx3gFx7hu2cmoGYGVJI5ggQZEbxt9KBcFiCxX93uSND4dPZtj7GmpMpnR12FzAYUWnAHwnT0br6cqYcPZJOutTsJ2fvEs5tAEKSofKZYER4ZjaYJ6VfcCwt+3aYMqB58IMbaSCV943pSdydOk1uUX/T11iGVSvLWNvQkGp1jsnI8bgc9NT/QCmmiol/DiUfBuzi2HNwtnbZdIid+Z1jSuXGuzSv47MJcHL5WH3SPLWIjc7TIYaKCSikrIxvtbwnEeGcNdGUGSBmXWI8Q570msWEqVJU6MII9NxuDqDyr9LVxxGEt3PjRW/mUN+dPNK2UhwIXzK6YrfssxTvgQjmTZdrYMESoCsmh2hXAjypvrnZsqgyooUdFAA+grpS15lunIKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooA//Z	vip	1000	SOLD	3	4	2026-04-15 23:23:27.744	11
3	acc1	yR5#NV]Ak,)+.:	https://www.instagram.com/p/DFZvfnKz3tZ/?img_index=1	vip	1000	SOLD	3	4	2026-04-16 00:58:17.056	3
4	dang1	eQ0,oyblwGDt_n	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	okk	1000	SOLD	12	4	2026-04-16 17:39:06.608	3
5	dang1	iO0_0%k[9X>x,(	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	acc ok	100000	SOLD	12	4	2026-04-16 17:41:37.422	3
6	dang1	cX5?l=99J-w^pn	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	vipp	100000	SOLD	12	4	2026-04-16 17:47:39.453	3
7	dang1	bC1!p&]Nu_!%&V	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	okok	11111	SOLD	12	4	2026-04-16 17:53:56.01	3
8	dang1	zA9<(8I1FOf<1O	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	11111	11111	SOLD	12	4	2026-04-16 18:03:02.377	3
9	dang1	fL3-o}q5:OjQoj	https://highmarksecurity.com/wp-content/uploads/2024/04/Anh-Acc-Nro-vip.jpg	11111	11111	SOLD	12	4	2026-04-16 18:11:15.398	3
11	thanhle3	123456	https://s3.hcm-1.cloud.cmctelecom.vn/bannick/storage/imageacc/3138d1cdf7255774802b2f1aeb3fc828.jpg	Acc VIP	1000000	ACTIVE	12	\N	2026-04-17 07:41:29.26	3
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.outbox_events (id, "sagaType", payload, status, retries, "maxRetries", "nextRetryAt", "lastError", "createdAt", "updatedAt") FROM stdin;
48ac8f85-601c-42b8-84e0-4ac540012439	BUY_ACCOUNT	{"id": 1, "user_id": 4, "idemKeys": {"changePass": "1:4:changePass", "changeEmail": "1:4:changeEmail", "deductBuyer": "1:4:deductBuyer", "creditPartner": "1:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "hE1*ENgQ+5Q1JO", "accountPrice": 122222}	FAILED	3	3	2026-04-15 17:17:20.659+00	2 UNKNOWN: Internal server error	2026-04-15 17:02:55.522871	2026-04-15 17:18:15.320778
06cc3a5f-e309-48b3-8ee0-63e027e9457f	BUY_ACCOUNT	{"id": 2, "user_id": 4, "idemKeys": {"changePass": "2:4:changePass", "changeEmail": "2:4:changeEmail", "deductBuyer": "2:4:deductBuyer", "creditPartner": "2:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "tE3-lMv1leFAEr", "accountPrice": 1000}	FAILED	3	3	2026-04-15 17:19:10.025+00	Cannot read properties of null (reading 'phase')	2026-04-15 17:15:31.058593	2026-04-15 17:19:15.008535
eebf40bd-caec-4a67-acfd-06c4bb194bff	BUY_ACCOUNT	{"id": 13, "userId": 4, "idemKeys": {"changePass": "13:4:changePass", "changeEmail": "13:4:changeEmail", "deductBuyer": "13:4:deductBuyer", "creditPartner": "13:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "uW5.Q(wHwxnmpe", "accountPrice": 20000}	DONE	0	3	2026-05-19 09:48:49.117+00	\N	2026-05-19 09:48:49.057459	2026-05-19 09:48:49.723294
648eb85d-c3db-4600-834a-0c505d9a3a96	BUY_ACCOUNT	{"id": 2, "user_id": 4, "idemKeys": {"changePass": "2:4:changePass", "changeEmail": "2:4:changeEmail", "deductBuyer": "2:4:deductBuyer", "creditPartner": "2:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "cA4>ow}yvws9l)", "accountPrice": 1000}	FAILED	3	3	2026-04-15 17:35:10.046+00	Cannot read properties of null (reading 'phase')	2026-04-15 17:31:31.798917	2026-04-15 17:35:15.038394
43a769f0-2546-4d54-9a30-691e7b8c42c0	BUY_ACCOUNT	{"id": 2, "user_id": 4, "idemKeys": {"changePass": "2:4:changePass", "changeEmail": "2:4:changeEmail", "deductBuyer": "2:4:deductBuyer", "creditPartner": "2:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "tR1@_xb0jsh7jT", "accountPrice": 1000}	FAILED	3	3	2026-04-15 17:12:15.629+00	Internal server error	2026-04-15 16:27:36.098823	2026-04-15 17:13:10.35568
bc89a2c2-4b74-4cc1-8099-8b3d097613bf	BUY_ACCOUNT	{"id": 3, "user_id": 4, "idemKeys": {"changePass": "3:4:changePass", "changeEmail": "3:4:changeEmail", "deductBuyer": "3:4:deductBuyer", "creditPartner": "3:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "yR5#NV]Ak,)+.:", "accountPrice": 1000}	DONE	0	3	2026-04-15 17:59:50.386+00	\N	2026-04-15 17:59:50.352468	2026-04-15 17:59:51.178011
a6c32684-e714-414d-8ba5-9d8ae9f93e82	BUY_ACCOUNT	{"id": 1, "user_id": 4, "idemKeys": {"changePass": "1:4:changePass", "changeEmail": "1:4:changeEmail", "deductBuyer": "1:4:deductBuyer", "creditPartner": "1:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "tY9?t&PB3svUi9", "accountPrice": 122222}	DONE	0	3	2026-04-15 18:00:43.756+00	\N	2026-04-15 18:00:43.739146	2026-04-15 18:00:44.389167
288b0a26-515b-4baf-9a65-0d92b211a8ce	BUY_ACCOUNT	{"id": 2, "user_id": 4, "idemKeys": {"changePass": "2:4:changePass", "changeEmail": "2:4:changeEmail", "deductBuyer": "2:4:deductBuyer", "creditPartner": "2:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "jN0{lo*;<-KcmL", "accountPrice": 1000}	DONE	3	3	2026-04-15 18:00:54.443+00	14 UNAVAILABLE: Connection dropped	2026-04-15 17:54:53.192429	2026-04-15 18:00:55.808283
de97a77c-111b-47e5-948a-c58088e7544b	BUY_ACCOUNT	{"id": 4, "userId": 4, "idemKeys": {"changePass": "4:4:changePass", "changeEmail": "4:4:changeEmail", "deductBuyer": "4:4:deductBuyer", "creditPartner": "4:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "eQ0,oyblwGDt_n", "accountPrice": 1000}	DONE	0	3	2026-04-16 10:39:22.954+00	\N	2026-04-16 10:39:22.918105	2026-04-16 10:39:23.670749
ee8c1206-85a7-4fe7-ae1c-5b4fa778033d	BUY_ACCOUNT	{"id": 5, "userId": 4, "idemKeys": {"changePass": "5:4:changePass", "changeEmail": "5:4:changeEmail", "deductBuyer": "5:4:deductBuyer", "creditPartner": "5:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "iO0_0%k[9X>x,(", "accountPrice": 100000}	DONE	0	3	2026-04-16 10:41:49.935+00	\N	2026-04-16 10:41:49.865872	2026-04-16 10:41:50.682709
a12b1a65-a079-49ab-ad65-b74e91ad188e	BUY_ACCOUNT	{"id": 6, "userId": 4, "idemKeys": {"changePass": "6:4:changePass", "changeEmail": "6:4:changeEmail", "deductBuyer": "6:4:deductBuyer", "creditPartner": "6:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "cX5?l=99J-w^pn", "accountPrice": 100000}	DONE	0	3	2026-04-16 10:48:04.016+00	\N	2026-04-16 10:48:04.013683	2026-04-16 10:48:04.840907
654eb280-ef04-4ef5-a729-21826b26bd45	BUY_ACCOUNT	{"id": 7, "userId": 4, "idemKeys": {"changePass": "7:4:changePass", "changeEmail": "7:4:changeEmail", "deductBuyer": "7:4:deductBuyer", "creditPartner": "7:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "bC1!p&]Nu_!%&V", "accountPrice": 11111}	DONE	0	3	2026-04-16 10:54:17.942+00	\N	2026-04-16 10:54:17.940757	2026-04-16 10:54:18.604997
6fd42a3f-f959-4d04-a716-ff9a3a3c5345	BUY_ACCOUNT	{"id": 8, "userId": 4, "idemKeys": {"changePass": "8:4:changePass", "changeEmail": "8:4:changeEmail", "deductBuyer": "8:4:deductBuyer", "creditPartner": "8:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "zA9<(8I1FOf<1O", "accountPrice": 11111}	DONE	0	3	2026-04-16 11:03:12.406+00	\N	2026-04-16 11:03:12.379885	2026-04-16 11:03:13.046796
9f20b5df-7082-4fda-b9b9-b13efaf975a2	BUY_ACCOUNT	{"id": 9, "userId": 4, "idemKeys": {"changePass": "9:4:changePass", "changeEmail": "9:4:changeEmail", "deductBuyer": "9:4:deductBuyer", "creditPartner": "9:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "fL3-o}q5:OjQoj", "accountPrice": 11111}	DONE	0	3	2026-04-16 11:11:29.276+00	\N	2026-04-16 11:11:29.242534	2026-04-16 11:11:29.95985
c14086ac-8730-4ced-ab12-7e5190fc869f	BUY_ACCOUNT	{"id": 10, "userId": 4, "idemKeys": {"changePass": "10:4:changePass", "changeEmail": "10:4:changeEmail", "deductBuyer": "10:4:deductBuyer", "creditPartner": "10:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "jU1*E.<%bev{X_", "accountPrice": 123456}	FAILED	3	3	2026-04-16 11:17:00.08+00	Cannot initialize saga state c14086ac-8730-4ced-ab12-7e5190fc869f	2026-04-16 11:13:23.176915	2026-04-16 11:17:05.022821
f90cfadb-4902-4466-a487-c414e15e8326	BUY_ACCOUNT	{"id": 10, "userId": 4, "idemKeys": {"changePass": "10:4:changePass", "changeEmail": "10:4:changeEmail", "deductBuyer": "10:4:deductBuyer", "creditPartner": "10:4:creditPartner"}, "username": "dangph.ptit@gmail.com", "newPassword": "aP9%682X%$pxBD", "accountPrice": 123456}	DONE	0	3	2026-04-17 00:44:59.417+00	\N	2026-04-17 00:44:59.402163	2026-04-17 00:45:00.222668
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.posts (id, title, url_anh, content, editor_id, editor_realname, status, create_at, update_at) FROM stdin;
5	[SỰ KIỆN] - GOKUDAY	https://forum.ngocrongonline.com/app/view/forum/6769b89edf.jpg	Chào các cư dân,\nAdmin sẽ tiến hành bảo trì để cập nhật nội dung sự kiện: GOKUDAY 2026.\n- Thời gian diễn ra sự kiện: từ bảo trì tối ngày 15/05/2026 đến 23h59 15/06/2026.\nNội dung của sự kiện như sau:\n1. KHUYẾN MÃI X3\nA. KHUYẾN MÃI THẺ NẠP\n- Từ 00h05 ngày 16/05 đến hết ngày 17/05\nB. KHUYẾN MÃI TIỀM NĂNG SỨC MẠNH\n- Từ 00h05 ngày 16/05 đến hết ngày 20/05\n2. ĐỔI ĐIỂM TẠI NPC QUY LÃO\nNgười chơi có thể đổi các vật phẩm có hạn sử dụng hoặc nếu may mắn sẽ nhận được vĩnh viễn tại NPC Quy Lão tại Đảo Kame.\nThời gian từ mở sự kiện đến hết 30/05\n3. Săn Hộp GokuDay\nA.Săn các boss để nhận hộp gokuday:\n+ Ăn Trộm\n+ Virut\n+ Ở Dơ\n+ Sói Héc Quyn\n+ Black Goku\nB.Làm nhiệm vụ Bò Mộng để nhận quà\n4. NHIỆM VỤ KOL THÁNG 5\nThời gian từ 15/05 - 15/06\nNạp 450 ngọc xanh (Không tính cộng dồn)\nPhần quà đặc biệt Goku Cận Vô Cực Vĩnh Viễn, ván bay MT vĩnh viễn\n5. CẬP NHẬT CỬA HÀNG\nA. Tại Santa\n+ Phiếu ngôi sao may mắn (vé vàng)\n+ Cờ Ngôi Sao May Mắn (tại mục cửa hàng hsd)\nB. Tại Chi Chi\nCác vật phẩm sự kiện\n6. ĐUA TOP\nA. ĐUA ĐỔI TOP HỘP THÁNG 5( Tại Quy Lão)\nTOP 1: Capsule cải trang VIP x4, Sách Cũ x70, Capsule 1 món kích hoạt x3, 3 Capsule vỡ, Đá Sức Mạnh x999, 1 Giáp Luyện Tập Cấp 5\nTOP 2: Capsule cải trang VIP x3, Sách Cũ x60, Capsule 1 món kích hoạt x2, 2 Capsule vỡ, Đá Thời Gian x500, 1 Giáp Luyện Tập Cấp 5\nTOP 3: Capsule cải trang VIP x2, Sách Cũ x50, Capsule 1 món kích hoạt x1, 1 Capsule vỡ, Đá Linh Hồn x500, 1 Giáp Luyện Tập Cấp 5\nTOP 4–10: Capsule cải trang VIP x1, Sách Cũ x20, Phiếu đổi capsule x50, 100 Mảnh Capsule vỡ, Đá Không Gian x200\nTOP 11–50: Sách Cũ x10, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\nTOP 51–100: Sách Cũ x5, Phiếu đổi capsule x10\nB. TOP MUA HỘP GOKUDAY (10 NGỌC)\nTOP 1: Ra Đa Ngọc Rồng Vip 200, Rương Mảnh Thiên Sứ x999, Capsule 1 món kích hoạt x3, 2 Capsule vỡ, 1 Giáp Luyện Tập Cấp 5\nTOP 2: Ra Đa Ngọc Rồng Vip 100, Rương Mảnh Thiên Sứ x500, Capsule 1 món kích hoạt x2, 1 Capsule vỡ\nTOP 3: Ra Đa Ngọc Rồng Vip 60, Rương Mảnh Thiên Sứ x400, Capsule 1 món kích hoạt x1, 250 Mảnh Capsule vỡ\nTOP 4–10: Ra Đa Ngọc Rồng Vip 40, Rương Mảnh Thiên Sứ x300, Phiếu đổi capsule x50, 100 Mảnh Capsule vỡ\nTOP 11–50: Ra Đa Ngọc Rồng Vip 20, Rương Mảnh Thiên Sứ x100, Phiếu đổi capsule x20, 20 Mảnh Capsule vỡ\nTOP 51–100: Ra Đa Ngọc Rồng Vip 10, Rương Mảnh Thiên Sứ x50, Phiếu đổi capsule x10\nC. TOP RƠI SÉT KÍCH HOẠT\nTOP 1: 5 Capsule 1 món kích hoạt, Pet Shimo vĩnh viễn [1568], 3 Capsule vỡ, Ra Đa Ngọc Rồng Vip 100\nTOP 2: 4 Capsule 1 món kích hoạt, Pet Shimo vĩnh viễn, 2 Capsule vỡ, Ra Đa Ngọc Rồng Vip 70\nTOP 3: 3 Capsule 1 món kích hoạt, Pet Shimo vĩnh viễn, 1 Capsule vỡ, Ra Đa Ngọc Rồng Vip 50\nTOP 4–10: 2 Capsule 1 món kích hoạt, Pet Shimo 180 ngày, 250 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 30\nTOP 11–50: Pet Shimo 90 ngày, 100 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 20\nTOP 51–100: Pet Shimo 60 ngày, 20 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 10\n7. VÒNG QUAY THƯỢNG ĐẾ\nThêm cải trang goku cận vô cực hsd và vĩnh viên trên vòng quay\n8. NẠP ĐẦU THÁNG\nNạp 10 ngọc nhận hộp đầu tháng\nNhà Là Để Trở Về	12	ADMIN	ACTIVE	2026-05-19 16:56:57.741	2026-05-19 17:03:01.868
9	[ĐIỀU CHỈNH] PHẦN THƯỞNG GIẢI SIÊU HẠNG	https://betaforum.ngocrongonline.com/app/view/forum/35b46c578c.jpg	Chào các Cư dân,\nBQT sẽ bảo trì cập nhật phần thưởng của Giải đấu Siêu hạng như sau:\nTOP 1: 200 Hồng Ngọc, 10 Rương Siêu Hạng, Danh hiệu cao thủ siêu hạng 3 ngày\nTOP 2: 100 Hồng Ngọc, 5 Rương Siêu Hạng\nTOP 3: 50 Hồng Ngọc, 2 Rương Siêu Hạng\nTOP 4–10: 20 Hồng Ngọc, 1 Rương Siêu Hạng\nTOP 11–20: 10 Hồng Ngọc\nTOP 21–100: 5 Hồng Ngọc\nTOP 101–1000: 2 Hồng Ngọc\n*Rương Siêu Hạng có thể mở ra các phần thưởng:\n- 50.000 vàng - 200.000 vàng\n- Mảnh bộ Sưu tập\n- Rương Sao Pha Lê Vip\n- Viên ngọc rồng 1 sao\n- Cải Trang Black Fide hạn sử dụng hoặc vĩnh viễn	12	ADMIN	ACTIVE	2026-05-19 17:04:51.143	2026-05-19 17:04:51.143
10	[CẬP NHẬT] SỰ KIỆN THÁNG 10	https://forum.ngocrongonline.com/app/view/forum/17292403311817.jpg	Thời Gian: sau bảo trì chiều ngày 18/10/2024.\nChào các cư dân, Admin cập nhật một số thông tin sau\n1. ĐIỀU CHỈNH KỸ NĂNG KAIOKEN\n- Trừ HP theo thời gian\n- Có hào quang riêng đặc biệt\n2. GIÁP LUYỆN TẬP 4\n- Bán tại Santa\n3. GIA HẠN MẦM\n- Chỉ áp dụng cho nhân vật còn mầm\n- Bán tại Santa bằng Ngọc Xanh\nLưu ý chỉ được mua 1 lần\nChúc các cư dân online vui vẻ	12	ADMIN	ACTIVE	2026-05-19 17:05:48.098	2026-05-19 17:05:48.098
3	abc	https://ngocrongonline.com//images/screen/2-2.png	abc22	3	thanh	LOCKED	2026-05-09 14:48:03.759	2026-05-09 14:48:17.4
2	ưefefe3f333	https://ngocrongonline.com//images/screen/2-2.png	ewfewfe	3	Dang	LOCKED	2026-04-15 22:02:41.796	2026-04-15 22:56:07.374
4	[GIẢI ĐẤU] NGỌC RỒNG SAO ĐEN ĐẶC BIỆT	https://forum.ngocrongonline.com/app/view/forum/758c6f725f.jpg	Chào các Cư Dân,\nAdmin sẽ mở thêm phần thưởng NGỌC RỒNG SAO ĐEN vào Chủ Nhật ngày 24/05/2026\nKhi Bang Hội chiến thắng tại Ngọc Rồng Sao Đen Số 1 (hành tinh M-2) ở KHU 1\nSẽ nhận thêm phần thưởng (chỉ nhận 1 lần):\n+ Bang Chủ: 99 thỏi vàng + 1 capsule cải trang Vip\nLưu Ý:\n+ Phải tham gia NRSD và còn đăng nhập trong game mới nhận được thưởng\n+ Phần thưởng chỉ nhận khi có giải đặc biệt	12	ADMIN	ACTIVE	2026-05-19 16:55:25.935	2026-05-19 16:55:25.935
6	[SỰ KIỆN] - ĐÁNH RƠI SET KÍCH HOẠT - ĐUA TOP CĂNG THẲNG	https://forum.ngocrongonline.com/app/view/forum/1772763234733.png	Chào các Cư Dân,\nAdmin tổ chức Đua Top ĐÁNH RƠI SÉT KÍCH HOẠT với nội dung như sau:\n- Đánh rơi 1 món sét kích hoạt sẽ được 1 điểm ( tính cả đánh rơi set champa và gonhan)\n- Nếu bằng điểm người nhặt sau sẽ được xếp trên\n\nPhần Thưởng :\nTOP 1: 5 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi vĩnh viễn, 3 Capsule vỡ, Ra Đa Ngọc Rồng Vip 100\nTOP 2: 4 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi vĩnh viễn, 2 Capsule vỡ, Ra Đa Ngọc Rồng Vip 70\nTOP 3: 3 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi vĩnh viễn, 1 Capsule vỡ, Ra Đa Ngọc Rồng Vip 50\nTOP 4–10: 2 Capsule 1 món kích hoạt, Bóng Mờ Tuyết Rơi 180 ngày, 250 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 30\nTOP 11–50: Bóng Mờ Tuyết Rơi 90 ngày, 100 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 20\nTOP 51–100: Bóng Mờ Tuyết Rơi 60 ngày, 20 Mảnh Capsule vỡ, Ra Đa Ngọc Rồng Vip 10\n\nChúc các Cư Dân Vui Vẻ !\n\n	12	ADMIN	ACTIVE	2026-05-19 16:58:02.396	2026-05-19 16:58:02.396
7	[SỰ KIỆN] - PHÁT HÀNH CẢI TRANG BLACK GOKU	https://forum.ngocrongonline.com/app/view/forum/17314053124792.jpg	•●◉✿ THÔNG BÁO ✿◉●•◦\nCẬP NHẬT CẢI TRANG BLACK GOKU\nChào các cư dân,\nAdmin tiến hành update nội dung phần cuối của sự kiện như sau:\nNội dung: 1. ĐẠI CHIẾN ZOMBIE\n* Áp dụng cho toàn bộ server\nTrong thời gian sự kiện sẽ xuất hiện các Zombie lang thang lây truyền bệnh khắp các bản đồ, các cư dân hãy hợp lực tiêu diệt để nhận về các phần thưởng hấp dẫn và có thể sở hữu chúng vĩnh viễn.\nLưu ý:\n- Các zombie thường xuất hiện ở khu 2 trở lên và không ở nơi tập trung các cư dân tân thủ\n- Ngoài ra ở cửa hàng Chi chi có bán rada giá 1 ngọc để có thể tìm kiếm và săn lùng dễ dàng hơn. 2. MỞ BÁN THÊM VẬT PHẨM Ở SHOP CHI CHI\nTrong thời gian sự kiện sẽ mở bán thêm các vật phẩm:\n- Lưỡi hái hồng\n- Rada dò Zombie\n- Còn tiếp...	12	ADMIN	ACTIVE	2026-05-19 17:00:25.067	2026-05-19 17:00:25.067
8	[FLASH SALE] - Black Friday  - Hàng khủng giá hạt dẻ	https://forum.ngocrongonline.com/app/view/forum/17008101481306.jpg	Chào các cư dân\nAdmin sẽ tiến hành bảo trì tất cả máy chủ để cập nhật chương trình giảm giá Black Friday.\n--- SĂN SALE HÀNG KHỦNG GIÁ BÈO ---\nThời gian: 12/5 đến hết 19/5\n- Mỗi ngày sẽ có chương trình Flash Sale các cư dân nhớ săn seo giảm giá hấp dẫn.\n- Cập nhật cải trang mới, Pet mới trong thời gian này.\nChúc các cư dân vui vẻ.	12	ADMIN	ACTIVE	2026-05-19 17:02:39.744	2026-05-19 17:02:39.744
\.


--
-- Data for Name: saga_state; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.saga_state (saga_id, phase, attempt, completed_steps, original_password, original_email, created_at, updated_at) FROM stdin;
a12b1a65-a079-49ab-ad65-b74e91ad188e	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-16 10:48:04.100512	2026-04-16 10:48:04.837341
eebf40bd-caec-4a67-acfd-06c4bb194bff	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-05-19 09:48:49.178401	2026-05-19 09:48:49.718658
48ac8f85-601c-42b8-84e0-4ac540012439	FORWARD	3	[]	123456	dangph.ptit@gmail.com	2026-04-15 17:02:55.631089	2026-04-15 17:06:25.491308
43a769f0-2546-4d54-9a30-691e7b8c42c0	FORWARD	5	[]	123456	dangph.ptit@gmail.com	2026-04-15 16:27:36.277107	2026-04-15 17:13:10.346439
654eb280-ef04-4ef5-a729-21826b26bd45	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-16 10:54:18.050785	2026-04-16 10:54:18.601132
bc89a2c2-4b74-4cc1-8099-8b3d097613bf	DONE	1	["changePass", "changeEmail", "deductBuyer", "creditPartner", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-15 17:59:50.478882	2026-04-15 17:59:51.174052
a6c32684-e714-414d-8ba5-9d8ae9f93e82	DONE	1	["changePass", "changeEmail", "deductBuyer", "creditPartner", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-15 18:00:43.779653	2026-04-15 18:00:44.385691
6fd42a3f-f959-4d04-a716-ff9a3a3c5345	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-16 11:03:12.46006	2026-04-16 11:03:13.042244
288b0a26-515b-4baf-9a65-0d92b211a8ce	DONE	1	["changePass", "changeEmail", "deductBuyer", "creditPartner", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-15 17:54:53.299711	2026-04-15 18:00:55.801447
9f20b5df-7082-4fda-b9b9-b13efaf975a2	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-16 11:11:29.371265	2026-04-16 11:11:29.956326
de97a77c-111b-47e5-948a-c58088e7544b	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-16 10:39:23.015656	2026-04-16 10:39:23.664687
f90cfadb-4902-4466-a487-c414e15e8326	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	fL3-o}q5:OjQoj	dangph.ptit@gmail.com	2026-04-17 00:44:59.476677	2026-04-17 00:45:00.219431
ee8c1206-85a7-4fe7-ae1c-5b4fa778033d	DONE	1	["deductBuyer", "changePass", "changeEmail", "creditPartner", "markSold", "emailSent"]	123456	dangph.ptit@gmail.com	2026-04-16 10:41:49.989121	2026-04-16 10:41:50.679055
\.


--
-- Data for Name: withdraw_money; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.withdraw_money (id, "userId", amount, bank_name, bank_number, bank_owner, status, finance_id, request_at, success_at) FROM stdin;
1	4	15000	Vietcombank	1023456789	PHAM HAI DANG	SUCCESS	1	2026-03-06 09:15:30	2026-03-06 10:30:45
2	2	50000	Techcombank	19035478921	DUNG NGUYEN	SUCCESS	1	2026-03-13 10:20:15	2026-03-13 11:45:22
3	11	100000	MB Bank	0123456789012	PHAM HAI DANG	SUCCESS	2	2026-03-19 13:10:25	2026-03-19 14:20:33
4	9	30000	BIDV	31010002345678	THANH LE	SUCCESS	1	2026-03-24 15:05:40	2026-03-24 16:15:48
5	6	20000	Vietcombank	1098765432	THANH LE	SUCCESS	2	2026-03-31 12:30:10	2026-03-31 13:40:17
6	1	40000	Vietcombank	1011223344	PHAM HAI DANG	SUCCESS	1	2026-04-06 10:15:18	2026-04-06 11:30:25
7	8	20000	ACB	2345678901	THANH LE	SUCCESS	2	2026-04-09 14:05:33	2026-04-09 15:20:14
8	20	80000	Techcombank	19038765432	LE TUAN	SUCCESS	1	2026-04-17 09:30:12	2026-04-17 10:45:33
9	13	30000	MB Bank	0987654321098	DANG	SUCCESS	2	2026-04-23 12:40:25	2026-04-23 13:55:42
10	18	50000	BIDV	31010009876543	DANG PHAM	SUCCESS	1	2026-04-29 16:15:08	2026-04-29 17:30:21
11	7	15000	Vietcombank	1056789012	THANH LE	SUCCESS	2	2026-04-20 08:25:45	2026-04-20 09:40:18
12	11	120000	MB Bank	0123456789012	PHAM HAI DANG	SUCCESS	1	2026-05-06 10:10:22	2026-05-06 11:25:39
13	6	25000	Vietcombank	1098765432	THANH LE	SUCCESS	2	2026-05-08 13:25:30	2026-05-08 14:40:52
14	8	60000	ACB	2345678901	THANH LE	SUCCESS	1	2026-05-12 15:15:42	2026-05-12 16:30:18
15	1	20000	Vietcombank	1011223344	PHAM HAI DANG	SUCCESS	2	2026-05-14 09:40:15	2026-05-14 10:55:44
16	4	40000	Vietcombank	1023456789	PHAM HAI DANG	SUCCESS	1	2026-05-17 14:05:22	2026-05-17 15:20:36
17	10	70000	Vietinbank	102100123456	THANH LE	SUCCESS	2	2026-05-18 12:30:18	2026-05-18 13:45:29
18	14	50000	Vietcombank	1099887766	TU NGUYEN DUY	ERROR	1	2026-04-18 10:20:35	\N
19	13	100000	MB Bank	0987654321098	DANG	ERROR	2	2026-04-25 14:15:48	\N
20	22	30000	Techcombank	19034567812	THAN TRAI DAT	ERROR	1	2026-05-02 11:30:22	\N
21	23	200000	BIDV	31010005678901	TAD2312	ERROR	2	2026-05-03 16:45:10	\N
22	28	80000	ACB	2398765432	SONGOKU	ERROR	1	2026-05-10 09:25:18	\N
23	35	50000	Vietcombank	1067891234	CUONG	ERROR	2	2026-05-11 13:40:55	\N
24	38	150000	Techcombank	19031122334	NAM	ERROR	1	2026-05-14 17:20:33	\N
25	40	25000	MB Bank	0345678901234	ROY	ERROR	2	2026-05-16 10:15:42	\N
27	25	60000	BIDV	31010003456789	CAI HUU THANH	ERROR	\N	2026-05-18 08:15:40	\N
28	26	35000	Techcombank	19036677889	TUNG PHAM VAN	ERROR	\N	2026-05-18 11:20:18	\N
29	29	90000	Vietcombank	1044556677	PIEH HAHE	ERROR	\N	2026-05-18 14:35:52	\N
30	42	120000	MB Bank	0556677889900	LURKER DARKNET	ERROR	\N	2026-05-18 15:50:30	\N
26	17	40000	Vietcombank	1077889900	DANG HAI	ERROR	\N	2026-05-17 18:30:25	\N
31	1	200000	Vietinbank	0123456789	Pham hai dang	PENDING	\N	2026-05-18 16:53:12.67	2026-05-18 09:53:12.639261
\.


--
-- Name: accounts_sell_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.accounts_sell_id_seq', 14, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.posts_id_seq', 10, true);


--
-- Name: withdraw_money_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.withdraw_money_id_seq', 31, true);


--
-- Name: posts PK_2829ac61eff60fcec60d7274b9e; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT "PK_2829ac61eff60fcec60d7274b9e" PRIMARY KEY (id);


--
-- Name: withdraw_money PK_599f3eab56751c2880b67e14465; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.withdraw_money
    ADD CONSTRAINT "PK_599f3eab56751c2880b67e14465" PRIMARY KEY (id);


--
-- Name: outbox_events PK_6689a16c00d09b8089f6237f1d2; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT "PK_6689a16c00d09b8089f6237f1d2" PRIMARY KEY (id);


--
-- Name: accounts_sell PK_a846a2d2a9945d55b50e10d7115; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.accounts_sell
    ADD CONSTRAINT "PK_a846a2d2a9945d55b50e10d7115" PRIMARY KEY (id);


--
-- Name: saga_state PK_fec0f9418d3166c4880fff8bd16; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.saga_state
    ADD CONSTRAINT "PK_fec0f9418d3166c4880fff8bd16" PRIMARY KEY (saga_id);


--
-- Name: IDX_5014f3712589d778539f4f4480; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_5014f3712589d778539f4f4480" ON public.accounts_sell USING btree (buyer_id);


--
-- Name: IDX_6c38bd2a65a4a6cec3c03638f2; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_6c38bd2a65a4a6cec3c03638f2" ON public.outbox_events USING btree (status, "nextRetryAt");


--
-- Name: IDX_6ede2ea9d14150e53adb6365e2; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_6ede2ea9d14150e53adb6365e2" ON public.withdraw_money USING btree ("userId");


--
-- Name: IDX_9f00e028f1e22d5ce786ebb411; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_9f00e028f1e22d5ce786ebb411" ON public.outbox_events USING btree (status, "updatedAt");


--
-- Name: IDX_aa6710601e531de2158434c82a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_aa6710601e531de2158434c82a" ON public.posts USING btree (editor_id);


--
-- Name: IDX_ea41a044d46098df360a09422b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_ea41a044d46098df360a09422b" ON public.accounts_sell USING btree (partner_id);


--
-- PostgreSQL database dump complete
--

\unrestrict o5R3egXLsSmMhB2Se3CIyOJsJEUdv0Npfmw5fyVnKoVnNWeiZcEeanjIitZevgT

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict 3RRJOOJrzQUbfr1botXRMzIEelbZuklIb4oicakK29DEdbWtRRgtjnG1UaUkoOM

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 3RRJOOJrzQUbfr1botXRMzIEelbZuklIb4oicakK29DEdbWtRRgtjnG1UaUkoOM

--
-- PostgreSQL database cluster dump complete
--

